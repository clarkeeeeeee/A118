#include "key.h"
#include "dev.h"
#include "self_check.h"
#include "led.h"
#include "connect.h"
#include "time.h"
#include "metrics.h"
#include "ack.h"
#include "brew.h"

#define KEY_TRIG_METRIC

sKey_t sKey;
bool KeyLongFlag=0;
eKey_t geKey;

#define SW1_DOWN	(!PF5)
#define SW2_DOWN	(!PC2)
#define SW3_DOWN	(!PC5)
#define SW4_DOWN	(!PC4)
#define SW5_DOWN	(!PF15)

#define LONG_TRIG		20
#define KEY_LONG_TH		50
#define KEY_DEBOUNCE	5

uint8_t SetTicks=0;

bool gbKeyUgsEn=false;
bool gbKeyFrsEn=false;
bool gbKeyFrsDown=false;
bool gbKeyUgsDown=false;

#define KEY_CODE_IO			1
#define KEY_CODE_WIFI		2
#define KEY_CODE_TIME		4
#define KEY_CODE_OPTION		8
#define KEY_CODE_READY		16
#define KEY_CODE_NONE		0

uint8_t gKeyStuck=0;

void KeyInit()
{
	uint8_t key_num=0; 
	
	GPIO_SetMode(PC, BIT2 |BIT4 |BIT5, GPIO_MODE_QUASI);
	GPIO_SetMode(PF, BIT5 |BIT15, GPIO_MODE_QUASI);
	PC2=1;
	PC4=1;
	PC5=1;
	PF5=1;
	PF15=1;
	
	if(SW1_DOWN)
		key_num+=1;
	if(SW2_DOWN)
		key_num+=2;
	#if(!DEBUG_ESO)
	if(SW3_DOWN)
		key_num+=4;
	#endif
	if(SW4_DOWN)
		key_num+=8;
	if(SW5_DOWN)
		key_num+=16;
	
	if(key_num==20)
		gbSelfCheckKeysEn=true;
	else if(key_num)
	{
		if(key_num==KEY_CODE_TIME)
			gKeyStuck=1;
		else if(key_num==KEY_CODE_READY)
			gKeyStuck=2;
		else if(key_num==KEY_CODE_WIFI)
			gKeyStuck=3;
		else if(key_num==KEY_CODE_OPTION)
			gKeyStuck=4;
		else if(key_num==KEY_CODE_IO)
			gKeyStuck=5;
		else 
			gKeyStuck=8;
		if(sKey.key_cnts==KEY_DEBOUNCE)
			gbMetrics__ERR_stuck_button=true;
	}
}
static void key_scan()
{
	uint8_t tmp=0;
	
	if(SW1_DOWN)
		tmp+=1;
	if(SW2_DOWN)
		tmp+=2;
	#if(!DEBUG_ESO)
	if(SW3_DOWN)
		tmp+=4;
	#endif
	if(SW4_DOWN)
		tmp+=8;
	if(SW5_DOWN)
		tmp+=16;
	
	if(tmp)
	{
		sKey.key_now=tmp;
		
		if(sKey.key_now!=sKey.key_pre)
		{
			sKey.key_cnts=0;
			sKey.key_pre=sKey.key_now;
		}
		else
		{
			sKey.key_cnts++;
		}
	}
	else
	{
		sKey.key_now=0;
	}
	
	if(sKey.key_cnts>=KEY_DEBOUNCE)
	{
		switch(sKey.key_now)
		{
			case KEY_CODE_IO:
				geKey=eKey_IO;
			break;
			case KEY_CODE_TIME:
				geKey=eKey_TIME;
			break;
			case KEY_CODE_WIFI:
				geKey=eKey_WIFI;
			break;
			case KEY_CODE_OPTION:
				geKey=eKey_OPTION;
			break;
			case KEY_CODE_READY:
				geKey=eKey_READY;
			break;
			default:
				geKey=eKey_Null;
			break;
		}
	}
}

extern uint8_t LcdTest;

bool gbUgsWait=false;
int32_t gUgsWaitCounts=0;
void KeyHandle()
{
	key_scan();
	
	if(sKey.key_now != KEY_CODE_WIFI)
	{
		gbKeyFrsDown=false;
		gbKeyUgsDown=false;
		gbResetWiFiCredentials=false;
	}
	
	if(gKeyStuck)
	{
		if(sKey.key_now)
			return;
		gKeyStuck=0;
	}
	
	if(gbSelfCheckKeysEn)
		goto Key_SelfCheck;

Key_SelfCheck:	
	
	if(sKey.key_now!=(KEY_CODE_TIME+KEY_CODE_READY))
		gbSelfCheckKeysEn=false;
	
	if(SelfCheckRetStatus())
	{
		switch(sKey.key_now)
		{
			case KEY_CODE_NONE:
				if(!sKey.key_lock)
				{
					
				}
				sKey.key_cnts=0;
				sKey.key_lock=0;
				sKey.key_pre=0;
				SelfCheckKeyCode=0;
			break;
				
			case KEY_CODE_IO:
				if(!sKey.key_lock)
				{
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						SelfCheckStepsPlus();
						sKey.key_lock=1;
						SelfCheckKeyCode=0;
					}
				}
			break;
				
			case KEY_CODE_TIME:
				if(!sKey.key_lock)
				{
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						sKey.key_lock=1;
						SelfCheckKeyCode=1;
						if(gbSelfCheckComplete)
							SelfCheckStepsPlus();
					}
				}
			break;
			case KEY_CODE_READY:
				if(!sKey.key_lock)
				{
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						sKey.key_lock=1;
						SelfCheckKeyCode=2;
						if(gbSelfCheckComplete)
							SelfCheckStepsPlus();
					}
				}
			break;
			case KEY_CODE_WIFI:
				if(!sKey.key_lock)
				{
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						sKey.key_lock=1;
						SelfCheckKeyCode=3;
						if(gbSelfCheckComplete)
							SelfCheckStepsPlus();
					}
				}
			break;
			case KEY_CODE_OPTION:
				if(!sKey.key_lock)
				{
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						sKey.key_lock=1;
						SelfCheckKeyCode=4;
						if(gbSelfCheckComplete)
							SelfCheckStepsPlus();
					}
				}
			break;
			
			default:
				sKey.key_lock=1;
				SelfCheckKeyCode=8;
			break;
		}
		return;
	}

Key_Handle:	
	switch(sKey.key_now)
	{
		case KEY_CODE_NONE:
			if(!sKey.key_lock && sKey.key_cnts>=KEY_DEBOUNCE)
			{
				if(sKey.key_pre==KEY_CODE_IO)
				{
					if(gbPower)
					{
						if(gCleaningRequiredLcd==CLEANING_REQUIRED_NO)
						{
							gCleaningRequired=CLEANING_REQUIRED_NO;
							gbPending_ToClear_gCleaningRequired=false;
						}
						DevPowerOff();
						#ifdef KEY_TRIG_METRIC
							Metrics_SetEndMethod(eMetrics_EndMethod_manual);
						#else
							;
						#endif
					}
					else
					{
						DevPowerOn_NoDevStatusCheck();
						#ifdef KEY_TRIG_METRIC
						
						Metrics_BrewCycleCountAdd();
						
						gbMetrics__brew_start_method=true;
						gbMetrics__brew_mode=true;
						
						gbMetrics__brew_start=true;
						Metrics__start_method=eMetrics_StartMethod_manual;
						#endif
					}
				}
				else if(sKey.key_pre==KEY_CODE_WIFI)
				{
					if(GetWifiSearchTicks())
					{
						LedResetWifiSearchTicks();
						goto NoAnyKey;
					}
					
					if(Conn_ModuleRegistered())
					{
					}
				}
				else if(sKey.key_pre==KEY_CODE_TIME)
				{
					gbTimeShow=!gbTimeShow;
					sTime.invalid_ticks=0;
				}
			}
			
NoAnyKey:
			sKey.key_cnts=0;
			sKey.key_lock=0;
			sKey.key_pre=0;
		break;
			
		case KEY_CODE_IO:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(sKey.key_cnts>=2000)
					{
//						SmgFirmwareVersionDispTicksReload();
						sKey.key_lock=1;
					}
				}
			}
		break;
			
		case KEY_CODE_TIME:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(TimeGetCfg()) 
					{
						if(sKey.key_cnts==KEY_DEBOUNCE || (sKey.key_cnts>=KEY_LONG_TH && ((sKey.key_cnts-KEY_LONG_TH)%LONG_TRIG)==0))
							TimeUpdateCauseKey();
//						sKey.key_lock=1;
						break;
					}
					
					if(sKey.key_cnts>=200)
					{
						TimeSetCfg();
						sKey.key_lock=1;
					}
				}
			}
		break;
			
		case KEY_CODE_WIFI:
			if(sKey.key_cnts>=KEY_DEBOUNCE)
				if(gbWifiLost)
					LedResetWifiSearchTicks();
				
//			if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA || ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
			{
				gbResetWiFiCredentials=true;
				LedResetWifiSearchTicks();
			}
//			else
//				gbResetWiFiCredentials=false;
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
//					if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_REGISTERED || ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
					{
						if(sKey.key_cnts>=200)
						{
							LedResetWifiSearchTicks();
							
//							ACK_ResetConnectivityModule();
//							gbUgsWait=true;
							gUgsWaitCounts=1000;
							Conn_StartUgs();
							gbKeyUgsDown=true;
							gbKeyUgsEn=true;
							
							
	//						gbSelfCheckKeysEn=false;
							sKey.key_lock=1;
							printf("\n\n ...............Conn_StartUgs \n");
						}
					}
//					else
//						sKey.key_lock=1;
				}
			}
			else if(gbResetWiFiCredentials)
			{
				if(sKey.key_cnts>=1230)
				{
					if(sKey.key_cnts==1230)
					{
						LedResetWifiSearchTicks();
						Conn_StartFrs();
						gbKeyFrsEn=true;
						gbKeyFrsDown=true;
						gbKeyUgsEn=gbKeyUgsDown=false;
//						gbSelfCheckKeysEn=false;
						printf("\n\n ...............Conn_StartFrs \n");
					}
				}
			}
		break;
			
		case KEY_CODE_READY:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(eDevStatus==eDevStatus_NotReadyToBrew || eDevStatus==eDevStatus_Other)
					{
						eDevStatus=eDevStatus_ReadyToBrew;
					}
					else if(eDevStatus==eDevStatus_ReadyToBrew)
					{
						eDevStatus=eDevStatus_NotReadyToBrew;
					}
					
					printf("KEY_CODE_READY   eDevStatus=%d",eDevStatus);
					sKey.key_lock=1;
					break;
				}
			}
		break;
			
		case KEY_CODE_OPTION:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(eBrewStrength==eBrewStrength_Regular)
						eBrewStrength=eBrewStrength_Bold;
					else
						eBrewStrength=eBrewStrength_Regular;
					sKey.key_lock=1;
					break;
				}
			}
		break;
		#if(0)	
		case KEY_CODE_PLUS:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					#ifdef KEY_UPDATE_TEMP_EN
					if(TempNow_Celsius<100)
						TempNow_Celsius+=1;
					TempNow_Fahrenheit=T_DegConvFromCToF(TempNow_Celsius);
					sKey.key_lock=1;
					#endif
					
					
					if(!DevGetTempSetStatus())
						break;
					DevReloadTempSetTicks();
					
					if(TempUnit==2)
					{
						if(sKey.key_cnts==KEY_DEBOUNCE)
							DevTempSet_CelsiusPlus(eKeyStatus_Down);
						else if(sKey.key_cnts>=1000)
							DevTempSet_CelsiusPlus(eKeyStatus_Long);
						break;
					}
					
					if(sKey.key_cnts==KEY_DEBOUNCE)
						DevTempSet_FahrenheitPlus(eKeyStatus_Down);
					else if(sKey.key_cnts>=1000)
						DevTempSet_FahrenheitPlus(eKeyStatus_Long);
				}
			}
		break;
			
		case KEY_CODE_MINUS:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					#ifdef KEY_UPDATE_TEMP_EN
					if(TempNow_Celsius)
						TempNow_Celsius--;
					TempNow_Fahrenheit=T_DegConvFromCToF(TempNow_Celsius);
					sKey.key_lock=1;
					#endif
					
					if(!DevGetTempSetStatus())
						break;
					DevReloadTempSetTicks();
					
					if(TempUnit==2)
					{
						if(sKey.key_cnts==KEY_DEBOUNCE)
							DevTempSet_CelsiusMinus(eKeyStatus_Down);
						else if(sKey.key_cnts>=1000)
							DevTempSet_CelsiusMinus(eKeyStatus_Long);
						break;
					}
					
					if(sKey.key_cnts==KEY_DEBOUNCE)
						DevTempSet_FahrenheitMinus(eKeyStatus_Down);
					else if(sKey.key_cnts>=1000)
						DevTempSet_FahrenheitMinus(eKeyStatus_Long);
				}
			}
		break;
		#endif	
		case KEY_CODE_TIME+KEY_CODE_READY:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(gbSelfCheckKeysEn)
					{
						if(sKey.key_cnts>=10)
						{
							SelfCheckStart();
							sKey.key_lock=1;
//							gbSelfCheckKeysEn=false;
						}
						break;
					}
				}
			}
		break;
		
		default:
			if(sKey.key_now)
				sKey.key_lock=1;
			
			if(sKey.key_cnts==KEY_DEBOUNCE)
				gbMetrics__ERR_stuck_button=true;
		break;
	}
}



