#include "self_check.h"
#include "dev.h"
#include "led.h"

bool gbSelfCheckKeysEn=false;
bool gbSelfCheckRelayOn=false;
bool gbSelfCheckComplete=false;

bool bSelfCheckStatus=false;
static uint32_t SelfCheckTicks=0;
static uint16_t SelfCheckSteps=0;

uint8_t SelfCheckKeyCode=0;
uint8_t SelfCheckErrorCode=0;

bool gbSelfCheckGetModuleInf=false;

void SelfCheckStart()
{
	if(!bSelfCheckStatus)
	{
		bSelfCheckStatus=true;
		SelfCheckTicks=0;
		SelfCheckSteps=0;
	}
}
void SelfCheckStop()
{
	if(bSelfCheckStatus)
	{
		bSelfCheckStatus=false;
		SelfCheckTicks=0;
	}
}
bool SelfCheckRetStatus()
{
	return bSelfCheckStatus;
}
uint8_t SelfCheckRetSteps()
{
	return SelfCheckSteps;
}
void SelfCheckStepsPlus()
{
	if(SelfCheckErrorCode)
		return;
	
	if(SelfCheckSteps>=1)
	{
		SelfCheckSteps++;
		SelfCheckTicks=0;
	}
}
void SelfCheckHandleForTmrInt()
{
	if(gbSelfCheckKeysEn)
		return;
	
	if(SelfCheckSteps==3)
	{
		if(gbSelfCheckGetModuleInf)
			SelfCheckTicks++;
		else
			return;
	}
	SelfCheckTicks++;
}

void SelfCheckHandle()
{
	if(!bSelfCheckStatus)
	{
		gbSelfCheckRelayOn=false;
		return;
	}
	
	switch(SelfCheckSteps)
	{
		case 0:
			if(SelfCheckTicks>=200)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 1:
		case 3:
		case 4:
		break;
			
		case 2:
			if(SelfCheckTicks>=100)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		
			
		case 5:
			if(SelfCheckTicks<100)
			{
				gbSelfCheckRelayOn=true;
				if(gbThermostatOff)
					SelfCheckErrorCode=1;
				else if(gbAcOff)
					SelfCheckErrorCode=2;
			}
			else
			{
				gbSelfCheckRelayOn=false;
				if(!SelfCheckErrorCode)
					gbSelfCheckComplete=true;
				if(SelfCheckTicks>=(100*60*5))
					SelfCheckSteps++;
			}
		break;
			
		default:
			bSelfCheckStatus=false;
		break;
	}
}



