#include "metrics.h"
#include "ack_metrics.h"
#include "ack.h"
#include "dev.h"
#include "time.h"
#include "brew.h"

#define METRICS_BUSY		30
uint16_t MetricsBusy=METRICS_BUSY;


void Metrics_ReloadMetricsBusy()
{
	MetricsBusy=METRICS_BUSY;
}

extern ACKLifecycleState_t ACK_LifecycleState;

sMetricsRtc_t sMetricsRtc;


uint16_t Metrics__PreSetBkp;
uint16_t Metrics__PreSetDelayReport=0;











const char kettle_start_time[]="kettle_start_time";
const char kettle_cycle_count[]="kettle_cycle_count";

const char kettle_start_method[]="kettle_start_method";
const char manual[]="manual";
const char remote[]="remote";


const char kettle_preset[]="kettle_preset";

bool gbMetrics__kettle_temp_units=false;
const char kettle_temp_units[]="kettle_temp_units";
const char kettle_temp_units_C[]="C";
const char kettle_temp_units_F[]="F";


bool gbMetrics__kettle_target_temp=false;
uint16_t Metrics__TempSet_FahrenheitBkp;
uint16_t Metrics__TempSet_FahrenheitDelayReport=0;
const char kettle_target_temp[]="kettle_target_temp";

bool Metrics__gbHeatingBkp=false;
const char kettle_start_temp[]="kettle_start_temp";
const char kettle_end_temp[]="kettle_end_temp";

bool Metrics__gbKeepWarmBkp=false;
const char kettle_KW_program[]="kettle_KW_program";







uint32_t Metrics__Kettle_heater_life=0;
uint32_t Metrics__kettle_relay_cycle=0;
bool gbMetrics__Kettle_heater_life=false;
bool gbMetrics__kettle_relay_cycle=false;
const char Kettle_heater_life[]="Kettle_heater_life";
const char relay_cycle_count[]="relay_cycle_count";



const char end_method_manual[]="manual";
const char end_method_ASO[]="ASO";
const char end_method_remote[]="remote";
const char end_method_Error[]="error";




bool gbMetrics__LowWater=false;
const char ERR_out_of_water[]="ERR_out_of_water";

//brew_end_method
const char brew_end_method[]="brew_end_method";
bool gbMetrics__brew_end_method=false;
eMetrics_EndMethod_t eMetrics_EndMethod=eMetrics_EndMethod_manual;
void Metrics_SetEndMethod(eMetrics_EndMethod_t method)
{
	eMetrics_EndMethod=method;
//	gbMetrics__brew_end_method=true;
}
static bool Metrics_brew_end_method()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_end_method)
	{
		gbMetrics__brew_end_method=false;
		
		switch(eMetrics_EndMethod)
		{
			case eMetrics_EndMethod_manual:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_manual);
			break;
			case eMetrics_EndMethod_ASO:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_ASO);
			break;
			case eMetrics_EndMethod_alexa:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_remote);
			break;
			case eMetrics_EndMethod_Error:
				ACK_SendUsageReportMetricWithStringValue(brew_end_method,end_method_Error);
			break;
			
			default:
				break;
		}
		
		printf("ACK_SendUsageReportMetricWithStringValue....brew_end_method:[%d]\n",eMetrics_EndMethod);
		return true;
	}
	return false;
}
//

static void Kettle_heater_life_handle()
{
	static uint32_t ticks=0;
	
	if(gbRelay)
	{
		if(++ticks>=(1000*60))
		{
			ticks=0;
			Metrics__Kettle_heater_life+=60;
			if(Metrics__Kettle_heater_life>5000000)
				Metrics__Kettle_heater_life=5000000;
		}
	}
}
static void kettle_relay_cycle_handle()
{
	static bool status=false;
	
	if(gbBrewRelay)
	{
		if(!status)
		{
			status=true;
			Metrics__kettle_relay_cycle++;
			if(Metrics__kettle_relay_cycle>200000)
				Metrics__kettle_relay_cycle=200000;
		}
	}
	else
	{
		if(eDevStatus<eDevStatus_Brewing && status)
		{
			gbMetrics__kettle_relay_cycle=true;
			gbMetrics__brew_end_method=true;
		}
		status=false;
	}
}



//keep_warm_duration
const char keep_warm_duration[]="keep_warm_duration";
bool gbMetrics__KW_duration=false;
uint16_t Metrics__KW_duration=0;

static void KW_duration_handle()
{
	static bool on=false;
	static uint32_t ticks=0;
	static uint16_t eso_counts=0;
	
	if(eso_counts!=EsoCounts)
	{
		eso_counts=EsoCounts;
		if(eso_counts)
			goto KW_duration_handle__report;
	}
	
	if(eDevStatus==eDevStatus_Brewing)
	{
		on=true;
		return;
	}
	if(eDevStatus==eDevStatus_KeepWarm || eDevStatus==eDevStatus_CoffeeReady)
	{
		on=true;
		ticks++;
		return;
	}
	
	KW_duration_handle__report:
	if(on)
	{
		ticks/=100;
		if(ticks>14400)
			ticks=14400;
		if(ticks>AUTO_POWER_OFF_DELAY_SECONDS)
			ticks=AUTO_POWER_OFF_DELAY_SECONDS;
		Metrics__KW_duration=ticks;
		ticks=0;
		on=false;
		gbMetrics__KW_duration=true;
	}
}
static bool Metrics_KW_duration()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__KW_duration)
	{
		gbMetrics__KW_duration=false;
		
		ACK_SendUsageReportMetricWithNumericValue(keep_warm_duration,Metrics__KW_duration);
		printf("ACK_SendUsageReportMetricWithNumericValue....keep_warm_duration:[%d]\n",Metrics__KW_duration);
		return true;
	}
	return false;
}


//brew_duration
const char brew_duration[]="brew_duration";
bool gbMetrics__brew_duration=false;
uint32_t Metrics__brew_duration=0;

static void brew_duration_handle()
{
	static bool on=false;
	static uint32_t ticks=0;
	static uint16_t eso_counts=0;
	
	if(eso_counts!=EsoCounts)
	{
		eso_counts=EsoCounts;
		if(eso_counts)
			goto brew_duration_handle__report;
	}
	if(eDevStatus==eDevStatus_KeepWarm || eDevStatus==eDevStatus_CoffeeReady)
	{
		on=true;
		return;
	}
	if(eDevStatus==eDevStatus_Brewing)
	{
		on=true;
		ticks++;
		return;
	}
	
	brew_duration_handle__report:
	if(on)
	{
		ticks/=100;
		if(ticks>1200)
			ticks=1200;
		Metrics__brew_duration=ticks;
		ticks=0;
		on=false;
		gbMetrics__brew_duration=true;
	}
}
static bool Metrics_brew_duration()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_duration)
	{
		gbMetrics__brew_duration=false;
		
		ACK_SendUsageReportMetricWithNumericValue(brew_duration,Metrics__brew_duration);
		printf("ACK_SendUsageReportMetricWithNumericValue....brew_duration:[%d]\n",Metrics__brew_duration);
		return true;
	}
	return false;
}
//


//ready_to_brew_state
bool gbMetrics__ready_to_brew_state=false;
const char ready_to_brew_state[]="ready_to_brew_state";
const char ready_to_brew_state1[]="TRUE";
const char ready_to_brew_state0[]="FALSE";
static bool Metrics_ready_to_brew_state()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__ready_to_brew_state)
	{
		gbMetrics__ready_to_brew_state=false;
		
		if(eDevStatus==eDevStatus_ReadyToBrew)
			ACK_SendUsageReportMetricWithStringValue(ready_to_brew_state,ready_to_brew_state1);
		else
			ACK_SendUsageReportMetricWithStringValue(ready_to_brew_state,ready_to_brew_state0);
		printf("ACK_SendUsageReportMetricWithStringValue....ready_to_brew_state\n");
		return true;
	}
	return false;
}


//


//brew_start
bool gbMetrics__brew_start=false;
const char brew_start[]="brew_start_time";

static bool Metrics_brew_start()
{
	uint8_t hh,mm,ss;
	float time=-1;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(!sTime.valid)
		return false;
	
	if(sTime.valid)
	{
		hh=sTime.hh;
		if(!sTime.am)
			if(hh<12)
				hh+=12;
		if(hh>=24)
			hh=0;
		mm=sTime.mm;
		ss=sTime.ss;
		time=hh*100+mm;
	}
	
	if(gbMetrics__brew_start)
	{
		gbMetrics__brew_start=false;
		
		ACK_SendUsageReportMetricWithNumericValue(brew_start,time);
		printf("ACK_SendUsageReportMetricWithStringValue....Metrics_brew_start:%f\n",time);
		return true;
	}
	return false;
}


//


//brew_count
uint16_t BrewCycleCount=0;
uint16_t BrewCycleCountBkp=0;
const char brew_count[]="brew_count";
void Metrics_BrewCycleCountAdd()
{
	if(BrewCycleCount<METRICS_KETTLE_CYCLE_COUNT_MAX)
		BrewCycleCount++;
}
static bool Metrics_cycle_count()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(BrewCycleCountBkp!=BrewCycleCount)
	{
		BrewCycleCountBkp=BrewCycleCount;
		
		ACK_SendUsageReportMetricWithNumericValue(brew_count,BrewCycleCountBkp);
		printf("ACK_SendUsageReportMetricWithNumericValue....brew_count:[%d]\n",BrewCycleCountBkp);
		return true;
	}
	return false;
}
//

//brew_start_method
const char brew_start_method[]="brew_start_method";
bool gbMetrics__brew_start_method=false;
eMetrics_StartMethod_t Metrics__start_method;
static bool Metrics_brew_start_method()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_start_method)
	{
		gbMetrics__brew_start_method=false;
		
		if(Metrics__start_method==eMetrics_StartMethod_manual)
			ACK_SendUsageReportMetricWithStringValue(brew_start_method,manual);
		else
			ACK_SendUsageReportMetricWithStringValue(brew_start_method,remote);
		printf("ACK_SendUsageReportMetricWithStringValue....brew_start_method:[%d]\n",Metrics__start_method);
		return true;
	}
	return false;
}
//

//brew_mode
const char brew_mode[]="brew_mode";
const char regular[]="regular";
const char bold[]="bold";
bool gbMetrics__brew_mode=false;
static bool Metrics_brew_mode()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__brew_mode)
	{
		gbMetrics__brew_mode=false;
		
		if(eBrewStrength==eBrewStrength_Regular)
			ACK_SendUsageReportMetricWithStringValue(brew_mode,regular);
		else
			ACK_SendUsageReportMetricWithStringValue(brew_mode,bold);
		printf("ACK_SendUsageReportMetricWithStringValue....brew_mode:[%d]\n",eBrewStrength);
		return true;
	}
	return false;
}
//



static bool Metrics_Kettle_heater_life()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__Kettle_heater_life)
	{
		gbMetrics__Kettle_heater_life=false;
		
		ACK_SendUsageReportMetricWithNumericValue(Kettle_heater_life,Metrics__Kettle_heater_life);
		printf("ACK_SendUsageReportMetricWithNumericValue....Kettle_heater_life:[%d]\n",Metrics__Kettle_heater_life);
		return true;
	}
	return false;
}
static bool Metrics_kettle_relay_cycle()
{
	static bool report=false;
	
	kettle_relay_cycle_handle();
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_relay_cycle)
	{
		gbMetrics__kettle_relay_cycle=false;
		
		ACK_SendUsageReportMetricWithNumericValue(relay_cycle_count,Metrics__kettle_relay_cycle);
		printf("ACK_SendUsageReportMetricWithNumericValue....relay_cycle_count:[%d]\n",Metrics__kettle_relay_cycle);
		return true;
	}
	return false;
}







const char FirmwareV[]={'U',0X30+FIRMWARE_VERSION/10,0X30+FIRMWARE_VERSION%10};
const char FW_HMCU[]="FW_HMCU";
#define METRICS_FW_HMCU_REPORTDELAY		(60*60*24*100)
static uint32_t Metrics_FW_HMCU_ReportDelay=0;
static bool Metrics_FW_HMCU()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	if(Metrics_FW_HMCU_ReportDelay)
		return false;
	
	Metrics_FW_HMCU_ReportDelay=METRICS_FW_HMCU_REPORTDELAY;
	ACK_SendUsageReportMetricWithStringValue(FW_HMCU,FirmwareV);
	printf("\nMetrics_FW_HMCU....\n");
	return true;
}

//ERR_Clean
const char ERR_Clean[]="ERR_Clean";
bool gbMetric__Clean=false;
static bool Metrics_ERR_Clean()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__Clean)
	{
		gbMetric__Clean=false;
		ACK_SendErrorMetric(ERR_Clean);
		printf("ACK_SendErrorMetric....ERR_Clean\n");
		return true;
	}
	return false;
}

//ERR_stuck_button
const char ERR_stuck_button[]="ERR_stuck_button";
bool gbMetrics__ERR_stuck_button=false;
static bool Metrics_ERR_stuck_button()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__ERR_stuck_button)
	{
		gbMetrics__ERR_stuck_button=false;
		ACK_SendErrorMetric(ERR_stuck_button);
		printf("ACK_SendErrorMetric....ERR_stuck_button\n");
		return true;
	}
	return false;
}
//ERR_ESO_Cnt
const char ERR_ESO_Cnt[]="ERR_ESO_Cnt";
bool gbMetric__Eso=false;
uint16_t MetricEsoCounts=0;
static bool Metrics_ERR_ESO_Cnt()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetric__Eso)
	{
		gbMetric__Eso=false;
		ACK_SendUsageReportMetricWithNumericValue(ERR_ESO_Cnt,MetricEsoCounts);
		printf("ACK_SendUsageReportMetricWithNumericValue....ERR_ESO_Cnt:[%d]\n",MetricEsoCounts);
		return true;
	}
	return false;
}




void MetricsHandle()
{
	bool status=false;
	
	if(MetricsBusy)
		return;
	
	status=Metrics_FW_HMCU();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_brew_start();		//1
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_brew_start_method();	//2
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_brew_mode();			//3
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_cycle_count();		//4
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	
	
	
	status=Metrics_brew_duration();		//5
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_KW_duration();		//6
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_kettle_relay_cycle();	//7
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	
	status=Metrics_brew_end_method();		//8
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_ERR_Clean();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_ERR_stuck_button();
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
//	status=Metrics_ERR_ESO_Cnt();
//	if(status)
//	{
//		MetricsBusy=METRICS_BUSY;
//		return;
//	}
//	status=Metrics_ready_to_brew_state();
//	if(status)
//	{
//		MetricsBusy=METRICS_BUSY;
//		return;
//	}
	
	
}

void MetricsHandleForTmrInt()
{
	if(MetricsBusy)
		MetricsBusy--;
	if(Metrics_FW_HMCU_ReportDelay)
		Metrics_FW_HMCU_ReportDelay--;
	
	brew_duration_handle();
	KW_duration_handle();
}
