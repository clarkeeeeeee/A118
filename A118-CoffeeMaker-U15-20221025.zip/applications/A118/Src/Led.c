#include "led.h"
#include "dev.h"
#include "self_check.h"
#include "ack.h"
#include "top.h"
#include "connect.h"

extern ACKLifecycleState_t ACK_LifecycleState;

#define LED_WIFI_SEARCH_TICKS		(5*60*100)
uint32_t Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
unsigned int LedFullTime=POWER_ON_ALL_SHOW_TIME;

bool GetWifiSearchTicks()
{
	return (Led_WifiSearchTicks>0);
}
bool LedResetWifiSearchTicks()
{
//	if(!Led_WifiSearchTicks && gbWifiLost)
	{
		Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
		return true;
	}
//	return false;
}

typedef enum
{
	eLedStatus_Off,
	eLedStatus_RedOn,
	eLedStatus_BlueOn,
	eLedStatus_RedBlinkingAt1Hz,
	eLedStatus_RedBlinkingAt2Hz,
	eLedStatus_RedBlueBlinkingAt1Hz,
	
	eLedStatus_RedBlinkingAt0Hz5,
	eLedStatus_BlueBlinkingAt0Hz5,
	eLedStatus_BlueBlinkingAt0S2,
	eLedStatus_BlueBlinkingAt1Hz,
}eLedStatus_t;

eLedStatus_t eLedStatus=eLedStatus_Off;
uint16_t WifiLedTicks=0;

#define DEF_POWER_LED_ON	PF4=1
#define DEF_POWER_LED_OFF	PF4=0
#define DEF_READY_LED_ON	PA0=1
#define DEF_READY_LED_OFF	PA0=0
#define DEF_WIFI_RED_LED_ON		PC1=1
#define DEF_WIFI_RED_LED_OFF	PC1=0
#define DEF_WIFI_BLUE_LED_ON	PC0=1
#define DEF_WIFI_BLUE_LED_OFF	PC0=0

bool gbWifiLost=false;
bool gbResetWiFiCredentials=false;
uint32_t LostWifiCounts=0;

void LedInit()
{
	GPIO_SetMode(PF, BIT4, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PA, BIT0, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, BIT0, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PC, BIT1, GPIO_MODE_OUTPUT);
	
	DEF_POWER_LED_OFF;
	DEF_READY_LED_OFF;
	DEF_WIFI_RED_LED_OFF;
	DEF_WIFI_BLUE_LED_OFF;
}

static void WifiLed()
{
	static eLedStatus_t eLedStatus_bkp;
	static bool bAlexaConnected=false;
	
//	eLedStatus=eLedStatus_Off;
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA || ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
	else
	{
		if(!Led_WifiSearchTicks)
		{
			eLedStatus=eLedStatus_Off;
			goto LedEx;
		}
	}
	
	if(gbResetWiFiCredentials && sKey.key_cnts>=1000)
	{
		WifiLedTicks=0;
		LostWifiCounts=0;
		#if(0)
		if(sKey.key_cnts>100 && sKey.key_cnts<=500)
		{
			if((sKey.key_cnts>100 && sKey.key_cnts<=150)\
				||(sKey.key_cnts>200 && sKey.key_cnts<=250)\
				||(sKey.key_cnts>300 && sKey.key_cnts<=350)\
				||(sKey.key_cnts>400 && sKey.key_cnts<=450)\
			)
			{
				DEF_WIFI_BLUE_LED_ON;
				DEF_WIFI_RED_LED_OFF;
			}
			else
			{
				DEF_WIFI_BLUE_LED_OFF;
				DEF_WIFI_RED_LED_OFF;
			}
		}
		else if(sKey.key_cnts>500 && sKey.key_cnts<=1000)
		{
			if((sKey.key_cnts>500 && sKey.key_cnts<=525)\
				||(sKey.key_cnts>550 && sKey.key_cnts<=575)\
				||(sKey.key_cnts>600 && sKey.key_cnts<=625)\
				||(sKey.key_cnts>650 && sKey.key_cnts<=675)\
				||(sKey.key_cnts>700 && sKey.key_cnts<=725)\
				||(sKey.key_cnts>750 && sKey.key_cnts<=772)\
				||(sKey.key_cnts>800 && sKey.key_cnts<=825)\
				||(sKey.key_cnts>850 && sKey.key_cnts<=875)\
				||(sKey.key_cnts>900 && sKey.key_cnts<=925)\
				||(sKey.key_cnts>950 && sKey.key_cnts<=975)\
			)
			{
				DEF_WIFI_BLUE_LED_ON;
				DEF_WIFI_RED_LED_OFF;
			}
			else
			{
				DEF_WIFI_BLUE_LED_OFF;
				DEF_WIFI_RED_LED_OFF;
			}
		}
		else
		#endif
		if(sKey.key_cnts>1000 && sKey.key_cnts<=1200)
		{
			DEF_WIFI_BLUE_LED_OFF;
			DEF_WIFI_RED_LED_ON;
		}
		else if(sKey.key_cnts>1200 && sKey.key_cnts<=1230)
		{
			if((sKey.key_cnts>1200 && sKey.key_cnts<=1205)\
				||(sKey.key_cnts>1210 && sKey.key_cnts<=1215)\
				||(sKey.key_cnts>1220 && sKey.key_cnts<=1225)\
			)
			{
				DEF_WIFI_BLUE_LED_OFF;
				DEF_WIFI_RED_LED_ON;
			}
			else
			{
				DEF_WIFI_BLUE_LED_OFF;
				DEF_WIFI_RED_LED_OFF;
			}
		}
		else
		{
			DEF_WIFI_BLUE_LED_OFF;
			DEF_WIFI_RED_LED_OFF;
		}
		return;
	}
	
	#if(0)
	if(gbKeyUgsDown)
	{
		eLedStatus=eLedStatus_BlueBlinkingAt0S2;
//		bWifiLost=false;
		bAlexaConnected=false;
		LostWifiCounts=0;
		goto LedEx;
	}
	if(gbKeyFrsDown)
	{
		eLedStatus=eLedStatus_RedOn;
//		bWifiLost=false;
		bAlexaConnected=false;
		LostWifiCounts=0;
		goto LedEx;
	}
	#endif
	if(gbKeyUgsEn)
	{
		eLedStatus=eLedStatus_BlueBlinkingAt0S2;
		gbWifiLost=false;
		bAlexaConnected=false;
		LostWifiCounts=0;
		goto LedEx;
		
	}
	if(gbKeyFrsEn)
	{
		eLedStatus=eLedStatus_BlueBlinkingAt1Hz;
		gbWifiLost=false;
		bAlexaConnected=false;
		LostWifiCounts=0;
		goto LedEx;
	}
	
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
	{
		eLedStatus=eLedStatus_BlueOn;
		bAlexaConnected=true;
		gbWifiLost=false;
		LostWifiCounts=0;
	}
	else if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
	{
		if(LostWifiCounts>=6000)
		{
			if(bAlexaConnected)
			{
				gbWifiLost=true;
				bAlexaConnected=false;
			}
			if(gbWifiLost)
				eLedStatus=eLedStatus_RedBlinkingAt0Hz5;
			else
				eLedStatus=eLedStatus_RedBlinkingAt1Hz;
		}
		
//		else if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
//			eLedStatus=eLedStatus_BlueBlinkingAt0Hz5;
//		else
//			eLedStatus=eLedStatus_Off;
	}
	else
	{
		LostWifiCounts=0;
		bAlexaConnected=false;
		if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
			eLedStatus=eLedStatus_BlueBlinkingAt0Hz5;
		else
			eLedStatus=eLedStatus_Off;
	}
	
//	if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
//		eLedStatus=eLedStatus_RedBlueBlinkingAt1Hz;
//	
//	else if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//		eLedStatus=eLedStatus_BlueOn;
//	
//	else if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//		eLedStatus=eLedStatus_RedOn;
//	
//	else if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE && ACK_LifecycleSubStateInfo.InSetupMode.IsUserGuidedSetupActive)
//		eLedStatus=eLedStatus_RedBlinkingAt2Hz;
//	
//	else //if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
//		eLedStatus=eLedStatus_RedBlinkingAt1Hz;
	
	LedEx:	
	if(eLedStatus_bkp!=eLedStatus)
	{
		eLedStatus_bkp=eLedStatus;
//		printf("\n\n eLedStatus = %d\n", eLedStatus_bkp);
	}
	switch(eLedStatus)
	{
		case eLedStatus_BlueBlinkingAt0S2:
			DEF_WIFI_RED_LED_OFF;
			if(WifiLedTicks<20)
			{
				DEF_WIFI_BLUE_LED_OFF;
			}
			else
			{
				DEF_WIFI_BLUE_LED_ON;
			}
			if(WifiLedTicks>=40)
				WifiLedTicks=0;
		break;
		case eLedStatus_BlueBlinkingAt0Hz5:
			DEF_WIFI_RED_LED_OFF;
			if(WifiLedTicks<100)
			{
				DEF_WIFI_BLUE_LED_OFF;
			}
			else
			{
				DEF_WIFI_BLUE_LED_ON;
			}
			if(WifiLedTicks>=200)
				WifiLedTicks=0;
		break;
		case eLedStatus_BlueBlinkingAt1Hz:
			DEF_WIFI_RED_LED_OFF;
			if(WifiLedTicks<50)
			{
				DEF_WIFI_BLUE_LED_OFF;
			}
			else
			{
				DEF_WIFI_BLUE_LED_ON;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
		case eLedStatus_RedBlinkingAt0Hz5:
			DEF_WIFI_BLUE_LED_OFF;
			if(WifiLedTicks<100)
			{
				DEF_WIFI_RED_LED_OFF;
			}
			else
			{
				DEF_WIFI_RED_LED_ON;
			}
			if(WifiLedTicks>=200)
				WifiLedTicks=0;
		break;
		
		case eLedStatus_Off:
			DEF_WIFI_RED_LED_OFF;
			DEF_WIFI_BLUE_LED_OFF;
		break;
		
		case eLedStatus_RedOn:
			DEF_WIFI_RED_LED_ON;
			DEF_WIFI_BLUE_LED_OFF;
		break;
		
		case eLedStatus_BlueOn:
			DEF_WIFI_RED_LED_OFF;
			DEF_WIFI_BLUE_LED_ON;
		break;
		
		case eLedStatus_RedBlinkingAt1Hz:
			DEF_WIFI_BLUE_LED_OFF;
			if(WifiLedTicks<50)
			{
				DEF_WIFI_RED_LED_ON;
			}
			else
			{
				DEF_WIFI_RED_LED_OFF;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
			
		case eLedStatus_RedBlinkingAt2Hz:
			DEF_WIFI_BLUE_LED_OFF;
			if(WifiLedTicks<25 || (WifiLedTicks>=50 && WifiLedTicks<75))
			{
				DEF_WIFI_RED_LED_ON;
			}
			else
			{
				DEF_WIFI_RED_LED_OFF;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
			
		case eLedStatus_RedBlueBlinkingAt1Hz:
			if(WifiLedTicks<50)
			{
				DEF_WIFI_RED_LED_ON;
				DEF_WIFI_BLUE_LED_OFF;
			}
			else
			{
				DEF_WIFI_RED_LED_OFF;
				DEF_WIFI_BLUE_LED_ON;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
		
		default:
		break;
	}
}

void LedHandleForTmrInt()
{
	LostWifiCounts++;
	WifiLedTicks++;
	if(Led_WifiSearchTicks)
	{
		Led_WifiSearchTicks--;
		if(!Led_WifiSearchTicks)
		{
			gbKeyUgsEn=false;
			gbKeyFrsEn=false;
		}
	}
	if(LedFullTime)
		LedFullTime--;
}

static void LedSelfCheck()
{
	static uint16_t ticks=0;
	static uint8_t step=0xff;
	
	if(!SelfCheckRetStatus())
		return;
	
	if(step!=SelfCheckRetSteps())
	{
		step=SelfCheckRetSteps();
		ticks=0;
	}
	
	switch(step)
	{
//		case 4:
//			if(ticks<50)
//				DEF_READY_LED_ON;
//			else
//				DEF_READY_LED_OFF;
//			DEF_POWER_LED_OFF;
//			DEF_WIFI_RED_LED_OFF;
//			DEF_WIFI_BLUE_LED_OFF;
//			if(++ticks>=100)
//				SelfCheckStepsPlus();
//		break;
//		case 3:
//			if(ticks<50)
//				DEF_POWER_LED_ON;
//			else
//				DEF_POWER_LED_OFF;
//			DEF_READY_LED_OFF;
//			DEF_WIFI_RED_LED_OFF;
//			DEF_WIFI_BLUE_LED_OFF;
//			if(++ticks>=100)
//				SelfCheckStepsPlus();
//		break;
		
		case 0:
			if(ticks<100)
			{
				DEF_WIFI_RED_LED_ON;
				DEF_WIFI_BLUE_LED_OFF;
			}
			else if(ticks<200)
			{
				DEF_WIFI_RED_LED_OFF;
				DEF_WIFI_BLUE_LED_ON;
			}
			DEF_POWER_LED_ON;
			DEF_READY_LED_ON;
			
			ticks++;
			if(ticks>200)
				ticks=200;
		break;
		
		case 3:
			if(ticks<300)
			{
				DEF_POWER_LED_OFF;
				DEF_READY_LED_OFF;
				DEF_WIFI_RED_LED_OFF;
				DEF_WIFI_BLUE_LED_OFF;
				ticks++;
				break;
			}
			
			if(gbSelfCheckGetModuleInf)
			{
				DEF_POWER_LED_OFF;
				DEF_READY_LED_OFF;
				DEF_WIFI_RED_LED_OFF;
				if(ticks<400)
					DEF_WIFI_BLUE_LED_ON;
				else
					DEF_WIFI_BLUE_LED_OFF;
				if(ticks<0xffff)
					ticks++;
			}
			else 
			{
				DEF_POWER_LED_OFF;
				DEF_READY_LED_OFF;
				DEF_WIFI_BLUE_LED_OFF;
				
				if(ticks<350)
					DEF_WIFI_RED_LED_ON;
				else
					DEF_WIFI_RED_LED_OFF;
				
				if(++ticks>=400)
					ticks=300;
			}
		break;
			
		default:
			DEF_POWER_LED_OFF;
			DEF_READY_LED_OFF;
			DEF_WIFI_RED_LED_OFF;
			DEF_WIFI_BLUE_LED_OFF;
		break;
	}
}

static void led_ready_brew()
{
	if(eDevStatus==eDevStatus_ReadyToBrew)
		DEF_READY_LED_ON;
	else
		DEF_READY_LED_OFF;
}
static void led_power()
{
	if(gbPower)
		DEF_POWER_LED_ON;
	else
		DEF_POWER_LED_OFF;
}

void LedHandle()
{
	if(SelfCheckRetStatus() || gbSelfCheckKeysEn)
	{
		LedSelfCheck();
		goto LedHandle_End;
	}
	
	if(LedFullTime)
	{
		DEF_POWER_LED_ON;
		DEF_READY_LED_ON;
		DEF_WIFI_RED_LED_ON;
		DEF_WIFI_BLUE_LED_ON;
		goto LedHandle_End;
	}
	
	#ifdef LED_IS_RELAY_STATUS
	if(gbRelay)
	{
		sLedRoutine.LedLeftWifiRedLedOn();
		sLedRoutine.LedRightWifiRedLedOn();
	}
	else
	{
		sLedRoutine.LedLeftWifiLedOff();
		sLedRoutine.LedRightWifiLedOff();
	}
	return;
	#endif
	
	WifiLed();
	led_ready_brew();
	led_power();
LedHandle_End:	
	;
}





