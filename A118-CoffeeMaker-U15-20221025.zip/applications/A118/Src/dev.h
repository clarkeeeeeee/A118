#ifndef _DEV_H_
#define _DEV_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"

#define CLEANING_REQUIRED_YES		1
#define CLEANING_REQUIRED_NO		2

typedef enum{
	eDevStatus_Other,
	eDevStatus_NotReadyToBrew,
	eDevStatus_ReadyToBrew,
	eDevStatus_Brewing,
	eDevStatus_CoffeeReady,
	eDevStatus_KeepWarm,
}eDevStatus_t;
extern eDevStatus_t eDevStatus;

typedef enum
{
	eBrewStrength_Other,
	eBrewStrength_Regular,
	eBrewStrength_Bold,
}eBrewStrength_t;
extern eBrewStrength_t eBrewStrength;

typedef enum
{
	eTimeSinceBrew_Other,
	eTimeSinceBrew_LessThan30minutes,
	eTimeSinceBrew_LessThan45minutes,
	eTimeSinceBrew_LessThan1hour,
	eTimeSinceBrew_LessThan75minutes,
	eTimeSinceBrew_LessThan90minutes,
	eTimeSinceBrew_LessThan105minutes,
	eTimeSinceBrew_LessThan2hour,
	eTimeSinceBrew_UnavailableAsBrewIsInOperation,
}eTimeSinceBrew_t;
extern eTimeSinceBrew_t eTimeSinceBrew;

extern uint8_t gCleaningRequired;
extern uint8_t gCleaningRequiredLcd;
extern bool gbThermostatOff;
extern bool gbAcOff;




extern bool gbPower;
extern uint16_t TempSet_Celsius;
extern uint16_t TempSet_Fahrenheit;
extern uint16_t TempNow_Celsius;
extern uint16_t TempNow_Fahrenheit;
extern uint16_t TempUnit;
extern bool gbAckDsnRecived;
extern bool gbRelay;
extern uint16_t PreSet;
extern uint16_t TempSet;

void DevInit();
void DevTempSet_FahrenheitPlus(eKeyStatus_t eKeyStatus);
void DevTempSet_FahrenheitMinus(eKeyStatus_t eKeyStatus);
void DevTempSet_CelsiusPlus(eKeyStatus_t eKeyStatus);
void DevTempSet_CelsiusMinus(eKeyStatus_t eKeyStatus);
bool DevReloadTempSetTicks();
bool DevGetTempSetFlashShow();
bool DevGetTempSetShow();
bool DevReloadTempSetTicks();
void DevHandleForTmrInt();
void DevClrTempSetTicks();
void DevHeaterRelay(bool);
bool DevGetTempSetStatus();
void DevHandle();
void UpdateTempSet_CelsiusFromTempSet();
void UpdateTempSet_FahrenheitFromTempSet();
void UpdateTempSet();
void UpdateTempSet_CausePreSet(uint16_t pre_set);
void DevPowerOff();
void DevPowerOn();
void UpdateTimeSinceBrew(uint16_t seconds);
void Update_gbThermostatOff();
void Update_gbAc();
void DevPowerOn_NoDevStatusCheck();

#endif



