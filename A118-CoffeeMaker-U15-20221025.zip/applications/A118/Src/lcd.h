#ifndef _LCD_H_
#define _LCD_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"

void LcdPortInit();
void LcdHandle();
void LcdScan();
void LcdHandleForTmrInt();


#endif



