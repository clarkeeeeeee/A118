#ifndef _BREW_H_
#define _BREW_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"


extern bool gbBrewRelay;
extern uint16_t EsoCounts;
extern bool gbPending_ToClear_gCleaningRequired;

void BrewHandle();
void BrewHandleForTmrInt();
void clear_eso_pra();

#endif



