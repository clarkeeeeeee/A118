#include "board.h"
#include "port.h"
#include "timer_process.h"

#include "key.h"
#include "dev.h"
#include "self_check.h"
#include "led.h"
#include "connect.h"
#include "data_save.h"
#include "lcd.h"
#include "time.h"
#include "brew.h"
#include "metrics.h"

static uint8_t TimerUsTicker;
static uint8_t TimerMsTicker;


void Timer_0_Init(void)
{
    /* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 10000); // 100000Hz = 0.00001s = 0.01ms = 10us

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER0);
    NVIC_EnableIRQ(TMR0_IRQn);

    /* Start Timer 0 */
    TIMER_Start(TIMER0);
}

void TMR0_IRQHandler(void)
{
    TimerUsTicker++;
    //printf("%d sec\n", sec++);

	if(TimerUsTicker == 10)
	{
		TimerUsTicker=0;
		#if !MY_RTC
		TimeRtcRun();
		#endif
	}
	
	Update_gbAc();
	Update_gbThermostatOff();
		
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER0);
}

uint16_t Timer1IntTimeMs=0;
uint16_t Timer1IntFreq=1000;

void Timer_1_Init(void)
{
    /* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER1, TIMER_PERIODIC_MODE, Timer1IntFreq); // 1000Hz  = 1ms
	Timer1IntTimeMs=1000/Timer1IntFreq;

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER1);
    NVIC_EnableIRQ(TMR1_IRQn);
	
	NVIC_SetPriority(TMR1_IRQn,1);

    /* Start Timer 0 */
    TIMER_Start(TIMER1);
}

extern uint16_t AckDelay;
extern int32_t gUgsWaitCounts;
extern int16_t PreCountsToUgs;

#include "my_rtc.h"

void TMR1_IRQHandler(void)
{
    static uint32_t timer1_sec = 1,msec = 0, min_timer=0, T_200ms=0;
    static uint16_t tmr1_int_counts=0;
	
	static uint16_t print_ticks=0;
	static uint16_t print_steps=0;
	
	if(++print_ticks>=1000)
	{
		print_ticks=0;
//		printf("\n system run %d ",print_steps++);
	}
	
	if(++tmr1_int_counts>=10)
		tmr1_int_counts=0;
	
	LcdScan();
	
	switch(tmr1_int_counts)
	{
		case 0:
			LcdHandle();
			LcdHandleForTmrInt();
		break;
		case 1:
			KeyHandle();
		break;
		case 2:
			LedHandle();
			LedHandleForTmrInt();
		break;
		case 3:
			BrewHandle();
			BrewHandleForTmrInt();
		break;
		case 4:
			MetricsHandleForTmrInt();
		break;
		case 5:
			SelfCheckHandle();
			SelfCheckHandleForTmrInt();
		break;
		
		case 6:
			if(sTime.valid)
				sTime.invalid_ticks=0;
			else 
				sTime.invalid_ticks++;
		break;
			
		case 7:
			gUgsWaitCounts--;
			if(PreCountsToUgs>0)
			{
				PreCountsToUgs--;
				if(PreCountsToUgs==0)
				{
					Conn_StartUgs();
					printf("\n\n\n>>>>>>>>>>>>>>>>>set sg_lifecyclePending USER_INITIATED_USER_GUIDED_SETUP \n\n\n");
				}
			}
		break;
		
		default:
			break;
	}
	
	
	TimeHandleForTmrInt();
			
	
    TimerMsTicker++;
	
	if(AckDelay)
		AckDelay--;

	DevHandleForTmrInt();
	
	Conn_ForTmrInt();
	DataSave_HandleForTmrInt();
	
	
	
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER1);
    
}

