#include "connect.h"
#include "ack.h"
#include "top.h"
#include "dev.h"

extern ACKLifecycleState_t ACK_LifecycleState;

extern void Alexa_InitiateFactoryReset(void);
extern void Alexa_InitiateUserGuidedSetup(void);
extern void Alexa_SendChangeReportDueToLocalControl(void);
uint32_t BeaconTicks=0;

uint32_t Status=2;
uint32_t CurrentTemperature=0;

bool gbModuleInSetupMode=false;

bool gbforceReport=false;

uint32_t AutoReportDelay=0;

static void UpdateStatus()
{
//	if(!gbPower)
//		Status=0;
//	if(gbLowWater)
//		Status=5;
//	else if(HeatintRetStatus())
//		Status=2;
//	else if(HeatintRetHeatingDone() || gbReadyStatus)
//		Status=3;
//	else if(KeepWarmRetStatus())
//		Status=4;
//	else
//		Status=1;
}

#define AUTO_REPORT_DELAY		3000


eDevStatus_t eDevStatus_Pre;
eBrewStrength_t eBrewStrength_Pre;
eTimeSinceBrew_t eTimeSinceBrew_Pre;

static void AutoReport(bool reload)
{
	static bool power=false;
	static uint8_t clean=0;
	static bool report=false;
	
	if(reload)
	{
		power=gbPower;
		eDevStatus_Pre=eDevStatus;
		eBrewStrength_Pre=eBrewStrength;
		eTimeSinceBrew_Pre=eTimeSinceBrew;
		clean=gCleaningRequired;
		report=false;
		AutoReportDelay=AUTO_REPORT_DELAY;
		return;
	}
	
	if(AutoReportDelay)
		return;
	
	if(gbforceReport)
	{
		gbforceReport=false;
		goto AutoReport_Reload;
	}
	
	if(power!=gbPower)
		goto AutoReport_Reload;
	if(eDevStatus_Pre!=eDevStatus)
		goto AutoReport_Reload;
	if(eBrewStrength_Pre!=eBrewStrength)
		goto AutoReport_Reload;
	if(eTimeSinceBrew_Pre!=eTimeSinceBrew)
		goto AutoReport_Reload;
	if(clean!=gCleaningRequired)
		goto AutoReport_Reload;
	
	goto AutoReport_Ex;
	
	AutoReport_Reload:
	{
		power=gbPower;
		eDevStatus_Pre=eDevStatus;
		eBrewStrength_Pre=eBrewStrength;
		eTimeSinceBrew_Pre=eTimeSinceBrew;
		clean=gCleaningRequired;
		
		report=true;
//		AutoReportDelay=3000;
		return;
	}
	
	AutoReport_Ex:
	{
		if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		{
			if(!AutoReportDelay)
				AutoReportDelay=1000;
			return;
		}
			
		if(report && !AutoReportDelay)
		{
			report=false;
			Alexa_SendChangeReportDueToLocalControl();
			AutoReportDelay=AUTO_REPORT_DELAY;
		}
	}
}

void Conn_Handle()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
		gbModuleInSetupMode=true;
	else
		gbModuleInSetupMode=false;
	
	AutoReport(false);
}

bool Conn_ModuleRegistered()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)// || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
		return true;
	return false;
}
static void ClrBeaconTicks()
{
	BeaconTicks=0;
}
void Conn_StartUgs()
{
	Alexa_InitiateUserGuidedSetup();
	ClrBeaconTicks();
}
void Conn_StartFrs()
{
	Alexa_InitiateFactoryReset();
	ClrBeaconTicks();
}


void Conn_ForTmrInt()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
	{
		if(++BeaconTicks>=ACK_LIFECYCLE_IN_SETUP_MODE_OT_TIME)
			gbModuleInSetupMode=false;
	}
	
	if(AutoReportDelay)
		AutoReportDelay--;
}








