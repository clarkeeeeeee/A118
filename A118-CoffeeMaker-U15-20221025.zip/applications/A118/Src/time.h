#ifndef _TIME_H_
#define _TIME_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"

typedef struct{
	int16_t hh;
	int16_t mm;
	int16_t ss;
	bool am;
	
	bool valid;
	uint8_t cfg_idx;
	uint16_t cfg_ticks;
	uint32_t invalid_ticks;
}sTime_t;

extern sTime_t sTime;
extern bool gbTimeShow;

bool TimeGetCfg();
void TimeSetCfg();
void TimeHandleForTmrInt();
void TimeUpdateCauseKey();
bool TimeGetCfgDisp();
void TimeUpdateCauseInternet(int16_t hh,int16_t mm,int16_t ss);
void TimeRtcRun();


#endif



