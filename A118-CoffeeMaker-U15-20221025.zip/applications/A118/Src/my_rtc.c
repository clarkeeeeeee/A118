#include "my_rtc.h"
#include "rtc.h"
#include "time.h"


S_RTC_TIME_DATA_T MyRtc;
S_RTC_TIME_DATA_T sCurTime;

static unsigned long MyRtcCounts=0;

void MyRtcInit()
{
	MyRtc.u32Year       = 2017;
    MyRtc.u32Month      = 5;
    MyRtc.u32Day        = 1;
    MyRtc.u32Hour       = 12;
    MyRtc.u32Minute     = 30;
    MyRtc.u32Second     = 0;
    MyRtc.u32DayOfWeek  = RTC_MONDAY;
    MyRtc.u32TimeScale  = RTC_CLOCK_24;
	
	RTC_CLKSRCRESET();
	RTC_CLKSRCSEL(RTC_CLKSRC_LIRC<<RTC_LXTCTL_C32KS_Pos);
	RTC_Open(&MyRtc);
	RTC_SetTickPeriod(RTC_TICK_1_SEC);
	RTC_EnableInt(RTC_INTEN_TICKIEN_Msk);
	NVIC_EnableIRQ(RTC_IRQn);
	RTC->INTSTS = 0x2;
	/* Get the current time */
    RTC_GetDateAndTime(&sCurTime);

    printf(" Current Time:%d/%02d/%02d %02d:%02d:%02d\n",sCurTime.u32Year,sCurTime.u32Month,
           sCurTime.u32Day,sCurTime.u32Hour,sCurTime.u32Minute,sCurTime.u32Second);
}

void RTC_IRQHandler()
{
	
	/* clear timer interrupt flag */
//    RTC_CLEAR_TICK_INT_FLAG();
	
	if ( (RTC->INTEN & RTC_INTEN_TICKIEN_Msk) && (RTC->INTSTS & RTC_INTSTS_TICKIF_Msk) )        /* tick interrupt occurred */
    {
        RTC->INTSTS = 0x2;

        TimeRtcRun();
    }
	
	printf("%s MyRtcCounts=%ld\r\n",__func__,MyRtcCounts++);
}























