#ifndef _SELF_CHECK_H_
#define _SELF_CHECK_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbSelfCheckKeysEn;
extern bool gbSelfCheckRelayOn;
extern bool gbSelfCheckGetModuleInf;
extern uint8_t SelfCheckKeyCode;
extern uint8_t SelfCheckErrorCode;
extern bool gbSelfCheckComplete;


bool SelfCheckRetStatus();
uint8_t SelfCheckRetSteps();
void SelfCheckHandle();
void SelfCheckHandleForTmrInt();
void SelfCheckStart();
void SelfCheckStop();
void SelfCheckStepsPlus();

#endif