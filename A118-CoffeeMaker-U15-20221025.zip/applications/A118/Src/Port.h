#ifndef __PORT_H
#define __PORT_H

#define	ProductID_Bit0   PF4 
#define	ProductID_Bit1   PF5 
#define	ProductID_Bit2   PA8 
#define	ProductID_Bit3   PA9 
	
#define	OPTO_EN   PA0

#define	MOTOR_PWM		PA15
#define	MOTOR_CTRL		PA14


typedef enum
{
	motor_speed_none=0,
	motor_speed_super_low,
	motor_speed_low,
	motor_speed_middle,
	motor_speed_high,
}TYPEDEF_MOTOR_SPEED;
//extern TYPEDEF_MOTOR_SPEED Motor_Speed;

typedef enum
{
	turn_none=0,
	turn_clockwise,
	turn_anti_clockwise
}TYPEDEF_TURN_DIR;

typedef enum
{
	TR_none = 0,
	TR_A,
	TR_AB,
	TR_B,
	TR_BC,
	TR_C,
	TR_CD,
	TR_D,
	TR_DA,
	
}TYPEDEF_TURN_RIGHT;
extern TYPEDEF_TURN_RIGHT TurnR;

typedef enum
{	
	Turn_none=0,
	Turn_Right,
	Turn_Left
}TYPEDEF_TURN_DIRECTION;
extern TYPEDEF_TURN_DIRECTION TURN_DIR;
extern TYPEDEF_TURN_DIRECTION SAVE_TURN_DIR;


void Turn_Clockwise(void);
void Turn_AntiClockwise(void);
void Turn_Process(TYPEDEF_TURN_DIRECTION Turn_D);
void StepperMotor_Process(bool TurnDir, uint16_t TurnAngle);


void Port_Init(void);
uint8_t Hardware_Product_Select(void);
void BlueLedBreathe_Disp(void);
void Motor_Pwm_Handle(void);

void turn_extra(void);
void Position_Init_Handle(void);



#endif

