/**************************************************************************//**
 * @brief    ACK HMCU platform porting.
 *
 * @note
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
 
#include "main.h"
#include "top.h"
/**
  * @brief  The application entry point.
  * @retval int
  */
void setup(void);
void loop(void);
void mcu_init(void);

uint16_t AckDelay=100;

bool TestUgs=false;

extern void Alexa_InitiateUserGuidedSetup(void);

int main(void)
{
    mcu_init();

#ifdef ALEXA
//    while(AckDelay);
	setup();
#endif
    while (1)
    {
		WDT_RESET_COUNTER();
		
        if(!AckDelay)
			UserEventLoop();
		
#ifdef ALEXA
		loop();
#endif		
    }
}

