#include "dev.h"
#include "top.h"
#include "self_check.h"
#include "brew.h"


eDevStatus_t eDevStatus;
eBrewStrength_t eBrewStrength=eBrewStrength_Regular;
eTimeSinceBrew_t eTimeSinceBrew;


bool gbThermostatOff=false;
bool gbAcOff=false;

uint8_t gCleaningRequired=CLEANING_REQUIRED_NO;
uint8_t gCleaningRequiredLcd=CLEANING_REQUIRED_NO;

bool gbAckDsnRecived=false;

bool gbPower=false;
uint16_t TempSet_Celsius=DEFAULT_TEMP_CELSIUS_SET;
uint16_t TempSet_Fahrenheit=DEFAULT_TEMP_FAHRENHEIT_SET;
uint16_t TempNow_Celsius=0;
uint16_t TempNow_Fahrenheit=0;
uint16_t TempSet=0;

uint16_t TempUnit=2;

uint16_t TempSetTicks=0;

bool gbRelay=false;

uint16_t PreSet=17;
uint16_t TempSet_CelsiusBkp=DEFAULT_TEMP_CELSIUS_SET;
uint16_t TempSet_FahrenheitBkp=DEFAULT_TEMP_FAHRENHEIT_SET;


#if(DEBUG_ESO)
#define THERMOSTAT_IO	!PC5
#else
#define THERMOSTAT_IO	PA8
#endif
void Update_gbThermostatOff()
{
	static uint16_t hold_ticks=0;
	static uint16_t check_ticks=0;
	
	if(!gbRelay)
	{
		hold_ticks=0;
		check_ticks=0;
		gbThermostatOff=false;
		return;
	}
	
	if(check_ticks<1000)
	{
		check_ticks++;
		if(!THERMOSTAT_IO)
			hold_ticks++;
		return;
	}
	else
		check_ticks=0;
	
	if(hold_ticks>250)
		gbThermostatOff=false;
	else
		gbThermostatOff=true;
	hold_ticks=0;
}
#define AC_IO	PA9
void Update_gbAc()
{
	static uint16_t hold_ticks=0;
	static uint16_t check_ticks=0;
	
	if(check_ticks<1000)
	{
		check_ticks++;
		if(!AC_IO)
			hold_ticks++;
		return;
	}
	else
		check_ticks=0;
	
	if(hold_ticks>250)
		gbAcOff=false;
	else
		gbAcOff=true;
	hold_ticks=0;
}

void DevPowerOff()
{
	if(gbPower)
	{
		gbPower=false;
		eDevStatus=eDevStatus_NotReadyToBrew;
		eTimeSinceBrew=eTimeSinceBrew_Other;
	}
}

void DevPowerOn()
{
	if(!gbPower && eDevStatus==eDevStatus_ReadyToBrew)
	{
		gbPower=true;
		eDevStatus=eDevStatus_Brewing;
		if(gCleaningRequired==CLEANING_REQUIRED_YES)
			gbPending_ToClear_gCleaningRequired=true;
		clear_eso_pra();
	}
}
void DevPowerOn_NoDevStatusCheck()
{
	if(!gbPower)
	{
		gbPower=true;
		eDevStatus=eDevStatus_Brewing;
		if(gCleaningRequired==CLEANING_REQUIRED_YES)
			gbPending_ToClear_gCleaningRequired=true;
		clear_eso_pra();
	}
}

//	eTimeSinceBrew_Other,
//	eTimeSinceBrew_LessThan30minutes,
//	eTimeSinceBrew_LessThan45minutes,
//	eTimeSinceBrew_LessThan1hour,
//	eTimeSinceBrew_LessThan75minutes,
//	eTimeSinceBrew_LessThan90minutes,
//	eTimeSinceBrew_LessThan105minutes,
//	eTimeSinceBrew_LessThan2hour,

#if(AUTO_POWER_OFF_DELAY_SECONDS<=120)
const uint16_t ConstSec=1;
#else
const uint16_t ConstSec=60;
#endif
void UpdateTimeSinceBrew(uint16_t seconds)
{
	if(eDevStatus==eDevStatus_Brewing)
	{
		eTimeSinceBrew=eTimeSinceBrew_UnavailableAsBrewIsInOperation;
		return;
	}
	if(!seconds)
		eTimeSinceBrew=eTimeSinceBrew_Other;
	else if(seconds<(30*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan30minutes;
	else if(seconds<(45*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan45minutes;
	else if(seconds<(60*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan1hour;
	else if(seconds<(75*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan75minutes;
	else if(seconds<(90*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan90minutes;
	else if(seconds<(105*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan105minutes;
	else if(seconds<(120*ConstSec))
		eTimeSinceBrew=eTimeSinceBrew_LessThan2hour;
}

void DevClrTempSetTicks()
{
	TempSetTicks=0;
}
bool DevReloadTempSetTicks()
{
	if(gbPower)
	{
		if(!TempSetTicks)
		{
			TempSetTicks=TEMP_SET_TICKS_POWER_ON;
			return true;
		}
		TempSetTicks=TEMP_SET_TICKS_POWER_ON;
		return false;
	}
	
	if(!TempSetTicks)
	{
		TempSetTicks=TEMP_SET_TICKS;
		return true;
	}
	TempSetTicks=TEMP_SET_TICKS;
	return false;
}
bool DevGetTempSetStatus()
{
	if(TempSetTicks)
		return true;
	return false;
}
bool DevGetTempSetFlashShow()
{
//	if(gbPower)
//		return true;
	if((TempSetTicks%1000)>=500)
		return true;
	return false;
}
bool DevGetTempSetShow()
{
	if(TempSetTicks)
		return true;
	return false;
}

void DevHandleForTmrInt()
{
	if(TempSetTicks)
		TempSetTicks--;
}

void DevHeaterRelay(bool on)
{
	
}



#define RELAY_ON	PF3=1
#define RELAY_OFF	PF3=0



void DevHandle()
{
	
	if(gbBrewRelay || gbSelfCheckRelayOn)
		gbRelay=true;
	else
		gbRelay=false;
	
	#if DEBUG_ESO
	RELAY_OFF;
	return;
	#endif
	
	if(gbRelay)
		RELAY_ON;
	else
		RELAY_OFF;
	
	
}







