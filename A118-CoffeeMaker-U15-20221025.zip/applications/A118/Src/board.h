#ifndef __BOARD_H
#define __BOARD_H

#include "numicro_hal.h"
#include "ack_logging.h"
#include <inttypes.h>
#include <stdint.h>

#include "port.h"
#include "led.h"


//#include "ack_user_config.h"

#define  LP450_SUPPORT 1 // liusj 20201223 created
//#define  PWM_DISP
//#define  PWM_DUTY_TEST  // just for switch duty 
#define  NEW_WAY

#define  DataFlash_As_Eeprom

// 20210206
#define  Tower_Fan  0x10
#define	Vor_ATOM1		0x01
#define	Vor_660			0x02
#define	Vor_6303DC		0x04
#define	Vor_Transom		0x08
#define	Vor_OSCR37		0x20

typedef enum
{
    idle=0,
    head_code,
    data_code,
    end_code,
        
}TYPEDEF_ENUM_SPEED;
extern TYPEDEF_ENUM_SPEED Speed_Step;

typedef enum
{
        idle_step=0,
        first_step,
        second_step,
        finally_step,
        
}TYPEDEF_ENUM_SLEEP_TIMER;
extern TYPEDEF_ENUM_SLEEP_TIMER SleepTimerSteps;


#define MergeToU16(u8)  ((0xffff & (u8<<8))|u8)

void TowerFan_Contr_Speed(uint16_t );


#ifdef LP450_SUPPORT
#define  PowerKey           0x0001
#define  SpeedKey			0x0002
#define  TimerKey			0x0004
#define  SleepModeKey		0x0008
#define  OSCKey         	0x0010

#define  FilterCheckKey         0x0005 // filter check -- press and hold PowerKey & TimerKey more then 5s

#define  EnterProvisioning      0x0009 // factory reset -- press and hold PowerKey & SleepModeKey more then 3s

#define  UserGuidedSetup    	0x000c // UGS -- User Guided Setup -- press and hold TimerKey & SleepModeKey more than 3s


#if 1 // 20210610 add
#define  Power_Key          0x0018
#define  SpeedUp_Key		0x0014
#define  SpeedDn_Key		0x0030

#define  TK0_Key			0x0001
#define  TK1_Key         	0x0002
#define  TK2_Key			0x0004
#define  TK3_Key         	0x0008

#define  TK6_Key			0x0040
#define  TK7_Key         	0x0080
#define  TK8_Key			0x0011
#define  TK9_Key         	0x0012
#endif


typedef enum
{
	KeyStep_init = 0,
	KeyStep_down,
	KeyStep_long,
	KeyStep_up
	
}KEY_SCAN_ENUM;


#define    KEY_NULL               0x0000
#define 	KEY_KEYDN	        0x1000
#define 	KEY_KEYHOLD	0x2000
#define 	KEY_KEYUP		0x4000

extern uint16_t gKEvt;

#define  	KEVT(KeyCode, Status)      (uint16_t)(KeyCode|Status)
#define	IsKeyPress(KeyCode)			      (gKEvt == KEVT(KeyCode, KEY_KEYDN))
#define	IsKeyHold(KeyCode)			   (gKEvt == KEVT(KeyCode, KEY_KEYHOLD))
#define	IsKeyUp(KeyCode)			     (gKEvt == KEVT(KeyCode, KEY_KEYUP))

typedef enum
{
	Position_none=0,
	Position_scan,
	Position_steady

}Position_Status;

typedef enum
{
    None_data,
    First_data,
    Second_data,
    Third_data,
    Last_data,
}RECEIVE_STEP;


typedef enum
{
	Idle_Disp = 0,
    Power_Disp,
    PowerOff_Disp,
    PowerHalf_Disp,
    PowerLevel10_Disp,
    Speed_Half_Disp,
    Speed_Disp,
    Position_Disp,
    Time_Disp,
    Sleep_Disp,
    Filter_Disp,
    UserGuide_Disp,
    Provisioned_Disp,
    
}DISPLAY_CASE;
//extern DISPLAY_CASE disp_case;

typedef enum
{
	pwr_led_none=0,
	pwr_led,
	blue_led_light,
	blue_led_dim,
	
	
}TYPEDEF_PWR_LED;


typedef struct
{
	bool DirectiveForSpeed;
	bool Disp_Speed_Led;
	bool Disp_Speed_Half_Led;
	bool DirectiveForTimer;
	bool SpeedChangeFromDirective;
	bool PressTimerKey_Event;
	bool Disp_Timer_Led;
	bool SleepModeOnOff;
	bool Disp_Sleep_Led;
	bool Disp_Filter_Led;
	bool Disp_UserGuied_Led;
	bool Disp_Provisioned_Led;
	bool FactoryResetFlag;
	bool Timer_was_setting;
	bool Manually_UserGuidedSetup;
	bool CancelTimerCount_Manually;
	bool FilterReset_Flag;
	bool PWR_LED_HALF;
	uint8_t Position_Det;
	bool Position_Init_OK;
	TYPEDEF_PWR_LED PWR_LED;
	uint8_t Counter_1_Sec;
	
	uint8_t FilterResetLED_Cnt;
	uint8_t Count_5s_MetricsTimer;
	uint8_t Count_5s_MetricsSpeed;
	uint8_t Count_5s_MetricsSleep;
	uint8_t Count_5s_MetricsPower;
	uint8_t Delay_5s_AfterUGS_Cnt;
	uint8_t Prov_Suc_Flash_Cnt;
	uint8_t ShortKeyUpFlag:1;
	uint8_t KeyBufferCnt_0;
	uint8_t KeyBufferCnt_1;
	uint16_t KeyArrayBuffer[8];
	uint8_t Counter_10_Sec;
	uint8_t Counter_5_Sec;
	uint8_t Counter_200_Ms;
	uint8_t Counter_1Hour_ForSleep;
	uint8_t SpecialCombinationButton; // SpecialCombinationButton
	uint8_t SpecialButton_Cnt_Sec;
	uint16_t FilterRemainingTimer;
	uint16_t WritePage0_cnt; 
	uint16_t WritePage1_cnt; 
	uint16_t WritePage2_cnt; 
	uint16_t WritePage3_cnt; 
	uint16_t Metrics_forSpeedKeepTime;
	uint16_t Metrics_forDreamKeepTime;
	uint32_t PercentOfFilter;
	DISPLAY_CASE disp_case;
	uint8_t Product_Type;
	uint8_t TR_MS_CNT;
	uint16_t Beats_Amount;
	uint16_t Beats_Sum;
	uint16_t TURN_ANGLE;
	uint16_t TURN_ANGLE_OFFSET;
	uint16_t TURN_ANGLE_SUM;
	
	uint8_t TowerSpeedValue;
	TYPEDEF_MOTOR_SPEED Motor_Speed;
	uint8_t TurnDirection;
	RECEIVE_STEP ReceiveDataStep;
	bool angle_offset_23;
    
}APP_PARAMETER;
extern APP_PARAMETER app_param;

uint8_t Hardware_Product_Select(void);

void  Erase_DataFlash(uint32_t u32StartAddr);
void  Save_RamainFilterLevel(uint32_t u32StartAddr, uint32_t u32Pattern);
uint32_t Read_RemainFilterLevel(uint32_t u32StartAddr) ;

void Send_Metrics_for_Timer(uint8_t timer);
void Send_Metrics_for_Speed(uint8_t speed);
void Send_Metrics_for_Sleep(void);
void Send_Metrics_for_Power(void);

void Alexa_SendChangeReportDueToLocalControl(void);
void Alexa_SendChangeReportForFilterRemainingLevel(void);

extern uint8_t Get_TK_Key;
extern uint8_t Save_TK_Key;


#define L_tube   1
#define R_tube  2
#define N_tube 0

#define  Digital_Select(L, R)   \
	{}
    /*if(L==L_tube && R==R_tube){ PC0 = 0; PF15 = 0;} \
    else if(L==L_tube && R==N_tube){ PC0 = 0;PF15 = 1;}\
    else if(R==R_tube && L==N_tube){ PC0 = 1;PF15 = 0;}\
    else{ PC0 = 1;PF15 = 1;}*/

// low active
#define  Tower_Digital_Select(onoff)    \
    if(onoff) \
        PC4 = 0; \
    else \
        PC4 = 1;

// low active
#define  SleepIndicatorLED(onoff)    \
    if(onoff) \
        PB0 = 0; \
    else \
        PB0 = 1;

// low active
#define  TimerIndicatorLED(onoff)   \
    if(onoff) \
        PC5 = 0; \
    else \
        PC5 = 1;


 #define  Tower_Communicate(onoff)	\
 	if(onoff) \
 		PB5 = 1; \
 	else \
 		PB5 = 0; \

// low active
 #define  Filter_LED(onoff)		((onoff)?(PB15=0):(PB15=1))
 
//#define  Tower_Communicate(onoff)  (onoff)?(PB5=1;):(PB5=0;)


// define pin for Speed controll
#define  Speed_SuperLow(onoff)      ((onoff) ? (PB7 = 1) : (PB7 = 0))
#define  Speed_Low(onoff)               ((onoff) ? (PB6 = 1) : (PB6 = 0))
#define  Speed_Medium(onoff)        ((onoff) ? (PB5 = 1) : (PB5 = 0))
#define  Speed_High(onoff)              ((onoff) ? (PB4 = 1) : (PB4 = 0))

extern uint32_t g_speedRange;
extern bool g_osc;

#define SPEED_MODE_NONE 0
#define SPEED_MODE_SUPER_LOW 1
#define SPEED_MODE_LOW 2
#define SPEED_MODE_MEDIUM 3
#define SPEED_MODE_HIGH 4

void Sleep_Process(void);

void Dev_Provisioning_UI(void);
void Dev_Provisioning_Successed(void);
void FilterReset_Disp_Event(void);


void Speed_Half_Display_Event(void);
void Speed_Display_Event(void);
void  PanelKey_Contr_Speed(void);
void Timer_CountDown(void);
void Filter_Display_Event(void);

extern uint8_t TK_KEY_Index;
extern uint8_t TK_KEY_Queue[8];
extern uint8_t TK_KEY_CONN;
extern uint8_t Save_TK_KEY_CONN;

void Parse_TK_Key(void);

// Timer controll
// Timer modes.
// Same as with the instance ids, these values must match the device type configuration.
#define TIMER_MODE_NONE 0
#define TIMER_MODE_SET_OFF      1
#define TIMER_MODE_1_HOUR 2
#define TIMER_MODE_2_HOUR 3
#define TIMER_MODE_3_HOUR 4
#define TIMER_MODE_4_HOUR 5
#define TIMER_MODE_5_HOUR 6
#define TIMER_MODE_6_HOUR 7
#define TIMER_MODE_7_HOUR 8
#define TIMER_MODE_8_HOUR 9

#define  Cnt_Hour_Select(a)     (3600*a)

// base timer "app_param.FilterRemainingTimer" is 1 minute
#define  Filter_Cnt_Hour(hour)  (hour*60) // such as : 1*60mins = 1hour, 320*60mins = 19200mins = 320hour

void Time_Display_Event(void);
void  PanelKey_Contr_Time(void);

extern bool gPower;
void Sleep_Switch(uint8_t OnOff);


void UserEventLoop(void);
void DigitalTube_1_Disp(void);
void DigitalTube_2_Disp(void);
void DigitalTube_3_Disp(void);
void DigitalTube_4_Disp(void);
void DigitalTube_5_Disp(void);
void DigitalTube_6_Disp(void);
void DigitalTube_7_Disp(void);
void DigitalTube_8_Disp(void);
void DigitalTube_9_Disp(void);
void DigitalTube_0_Disp(void);
void DigitalTube_H_Disp(void);
void DigitalTube_r_Disp(void);
void DigitalTube_Clean_Disp(void);
void Digital_8_D(void);
void Digital_9_D(void);
void Digital_0_D(void);
void Digital_Clean_D(void);
void Delay_ms(uint32_t cnt);
void Hardware_GPIO_Init(void);
void HubPowerSwitch(bool onoff);

void Key_Process_Event(void);
void Display_Process_Event(void);

uint32_t Hardware_GetFilterRemainingLife( void );

extern int g_bDoRestoreFactorySetting;
extern bool g_bDoUserGuidedSetup;


#endif

#define  DataFlashWriteMaxCnt	1000//(20000-1)

#define DataFlashPage0	 ACK_NUMICRO_EEPROM_START // 0x0001 F800
#define DataFlashPage1	(ACK_NUMICRO_EEPROM_START+(FLASH_PAGE_SIZE*1)) // 0x0001 F800 + 512byte(Hex:200) = 0x0001 FA00
#define DataFlashPage2	(ACK_NUMICRO_EEPROM_START+(FLASH_PAGE_SIZE*2)) // 0x0001 F800 + (512byte * 2)(Hex:400) = 0x0001 FC00
#define DataFlashPage3	(ACK_NUMICRO_EEPROM_START+(FLASH_PAGE_SIZE*3)) // 0x0001 F800 + (512byte * 3)(Hex:600) = 0x0001 FE00




#define DEF_ENABLE_HMCU_INDICTOR_BLINK          (1)
#define DEF_ENABLE_RESTORE_FACTORY_SETTING  (1)

typedef enum
{
	// UART0 for Debug printf
    D0 = PB_2,
    D1 = PB_3,

    // UART naming
    USBTX = PB_13,
    USBRX = PB_12,
    STDIO_UART_TX   = USBTX,
    STDIO_UART_RX   = USBRX,
    SERIAL_TX = USBTX,
    SERIAL_RX = USBRX,
	ACK_INT = PA_6,
	ACK_EN = PC_3,
} Board_PinName;

typedef enum
{
    eUserGPIODev_HeartBeat,
    eUserGPIODev_RestoreFactorySetting,
    eUserGPIODev_ACK_PowerEnable
} E_USERGPIODEV;

typedef enum
{
    eUartDev_DBG,
	eUartDev_ACK,
    eUartDev_TK
} E_UARTDEV;

extern S_UARTDev    g_asBoardUartDev[];
extern S_GPIODev    g_asBoardGpioDev[];
extern S_PWMDev   g_asBoardPwmDev[];
extern S_CRCDev     g_sCrcDev;

void peripheral_init(void);

bool UART2_SendCmd_Get_EEPROM(void);

#endif /* __BOARD */

