
#include "board.h"
#include "port.h"

TYPEDEF_TURN_RIGHT TurnR;
TYPEDEF_TURN_DIRECTION TURN_DIR;
TYPEDEF_TURN_DIRECTION SAVE_TURN_DIR;

void Port_Init(void)
{
	GPIO_SetMode(PF, BIT3, GPIO_MODE_OUTPUT);	//RELAY
	PF3=0;
	
	GPIO_SetMode(PA, BIT8, GPIO_MODE_QUASI);	//ZERO
	GPIO_SetMode(PA, BIT9, GPIO_MODE_QUASI);
	PA8=1;
	PA9=1;
}



