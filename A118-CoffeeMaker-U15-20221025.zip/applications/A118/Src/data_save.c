#include "data_save.h"
#include "data_flash.h"
#include "dev.h"
#include "connect.h"
#include "fmc.h"
#include "ack_m031_ota.h"
#include "metrics.h"


#define DATA_SAVE_HEAD		20220711	//no change,ota no reset eeprom
#define DATA_SAVE_DELAY		3000

#define EEPROM_LEN				8
#define EEPROM_LEN_BYTE			(EEPROM_LEN*4)
#define EEPROM_ADDR				ACK_NUMICRO_EEPROM_START

uint32_t Save[EEPROM_LEN]={DATA_SAVE_HEAD};
uint32_t Read[EEPROM_LEN]={};
uint32_t Read2[EEPROM_LEN]={};
	
uint32_t DataSaveDelay=0;
	
	
uint32_t EepromAddr=EEPROM_ADDR;

#define BREW_STRENGTH_SAVE	0	

static void UpdateData(uint32_t *src)
{
	uint32_t tmp;
	
	tmp=*src;
	#if BREW_STRENGTH_SAVE
	eBrewStrength=tmp&0XFF;
	printf("read eBrewStrength is %d",tmp);
	#endif
	
	BrewCycleCountBkp=BrewCycleCount=*(src+1);
	Metrics__kettle_relay_cycle=*(src+2);
}
static void UpdateSave(uint32_t *save)
{
	uint32_t tmp;
	
	#if BREW_STRENGTH_SAVE
	tmp=eBrewStrength;
	*save=tmp;
	#endif
	
	*(save+1)=BrewCycleCount;
	*(save+2)=Metrics__kettle_relay_cycle;
}




uint32_t read_test[16];

void DataSave_Read()
{
	uint32_t i=0;
	uint32_t tab_idx=0;
	
//	DataFlash_Read(EEPROM_ADDR,read_test,16);
	
	for(i=0;i<ACK_NUMICRO_EEPROM_SIZE;i+=EEPROM_LEN_BYTE)
	{
		DataFlash_Read(EEPROM_ADDR+i,Read,EEPROM_LEN);	
		
		if(Read[0]==DATA_SAVE_HEAD)
		{
			for(tab_idx=0;tab_idx<EEPROM_LEN;tab_idx++)
				Read2[tab_idx]=Read[tab_idx];
			if(i==(ACK_NUMICRO_EEPROM_SIZE-EEPROM_LEN_BYTE))
				goto ReadSucc;
		}
		else
		{
			if(i==0)
				return;
			EepromAddr+=(i);
			goto ReadSucc;
		}
	}
	
	ReadSucc:
	if(Read2[0]==DATA_SAVE_HEAD)
	{
		UpdateData(&Read2[1]);
		DataSave_Scan(true);
	}
	
	
}


int32_t Write_Eeprom()
{
	int32_t ret;
	
	ret=DataFlash_Save(EepromAddr,Save,EEPROM_LEN);
	EepromAddr+=EEPROM_LEN_BYTE;
	if(EepromAddr>=(EEPROM_ADDR+ACK_NUMICRO_EEPROM_SIZE))
		EepromAddr=EEPROM_ADDR;
	printf("\nNext EepromAddr is [0x%x]!\n", EepromAddr);
	return ret;
}

void DataSave_Scan(bool update)
{
	static uint8_t tmp[6];
	static bool save=false;
	static uint16_t kettle_cycle_count;
	static uint32_t Kettle_heater_life;
	static uint32_t kettle_relay_cycle;
	
	if(update)
	{
		tmp[0]=eBrewStrength;
		kettle_cycle_count=BrewCycleCount;
//		Kettle_heater_life=Metrics__Kettle_heater_life;
		kettle_relay_cycle=Metrics__kettle_relay_cycle;
		return;
	}
	
	#if BREW_STRENGTH_SAVE
	if(tmp[0]!=eBrewStrength\
		|| kettle_cycle_count!=BrewCycleCount\
		|| kettle_relay_cycle!=Metrics__kettle_relay_cycle
		)
	#else
	if(kettle_cycle_count!=BrewCycleCount\
		|| kettle_relay_cycle!=Metrics__kettle_relay_cycle
		)
	#endif
	{
		tmp[0]=eBrewStrength;
		kettle_cycle_count=BrewCycleCount;
		kettle_relay_cycle=Metrics__kettle_relay_cycle;
		
		save=true;
		DataSaveDelay=DATA_SAVE_DELAY;
	}
	
	if(save && !DataSaveDelay)
	{
		UpdateSave(&Save[1]);
		
		if(Write_Eeprom()==-1)
		{
			DataSaveDelay=DATA_SAVE_DELAY;
			return;
		}
		
		save=false;
	}
}

void DataSave_HandleForTmrInt()
{
	if(DataSaveDelay)
		DataSaveDelay--;
}










