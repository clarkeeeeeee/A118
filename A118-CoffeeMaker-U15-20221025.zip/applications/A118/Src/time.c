#include "time.h"

sTime_t sTime={12,0,0,true};

bool gbTimeShow=true;

bool bTimeForceUpdate=false;
	
static bool TimeReloadCfgTicks()
{
	if(!sTime.cfg_ticks)
	{
		sTime.cfg_ticks=3000;
		return true;
	}
	sTime.cfg_ticks=3000;
	return false;
}
bool TimeGetCfg()
{
	return sTime.cfg_idx;
}
void TimeSetCfg()
{
	sTime.cfg_idx++;
	if(sTime.cfg_idx<3)
		TimeReloadCfgTicks();
	else
	{
		sTime.cfg_idx=0;
		sTime.valid=1;
		gbTimeShow=true;
		sTime.invalid_ticks=0;
//		if(sTime.hh==12)
//			sTime.am=!sTime.am;
	}
}

void TimeHandleForTmrInt()
{
	if(sTime.cfg_ticks)
	{
		sTime.cfg_ticks--;
		if(!sTime.cfg_ticks)
		{
			TimeSetCfg();
		}
	}
}

#define UPDATE_TIME_DELAY	(10)
void TimeRtcRun()
{
	static uint16_t time_run_sec_ticks=0;
	static int16_t update_time_delay=UPDATE_TIME_DELAY;
	
	if(sTime.cfg_idx)
		time_run_sec_ticks=0;
	#if MY_RTC
	else if(++time_run_sec_ticks>=1)
	#else
	else if(++time_run_sec_ticks>=1000)
	#endif
	{
		if(update_time_delay>0)
			update_time_delay--;
		if(update_time_delay==0)
		{
			bTimeForceUpdate=true;
			update_time_delay=UPDATE_TIME_DELAY;
		}
		
		
		time_run_sec_ticks=0;
		if(++sTime.ss>=60)
		{
			sTime.ss=0;
			if(++sTime.mm>=60)
			{
				sTime.mm=0;
				sTime.hh++;
				if(sTime.hh==12)
					sTime.am=!sTime.am;
				if(sTime.hh==13)
					sTime.hh=1;
			}
		}
		
		if(sTime.am && sTime.hh==2 && sTime.mm==1 && sTime.ss==0)
			bTimeForceUpdate=true;
	}
}

void TimeUpdateCauseKey()
{
	if(!sTime.cfg_idx)
		return;
	
	if(sTime.cfg_idx==1)
	{
		sTime.hh++;
		if(sTime.hh==12)
			sTime.am=!sTime.am;
		if(sTime.hh>=13)
		{
			sTime.hh=1;
//			sTime.am=!sTime.am;
		}
		TimeReloadCfgTicks();
	}
	if(sTime.cfg_idx==2)
	{
		if(++sTime.mm>59)
			sTime.mm=0;
		TimeReloadCfgTicks();
	}
}

void TimeUpdateCauseInternet(int16_t hh,int16_t mm,int16_t ss)
{
	if(sTime.valid && !bTimeForceUpdate)
		return;
	
	if(bTimeForceUpdate)
		printf("\n\n ----------bTimeForceUpdate \r\n");
	
	bTimeForceUpdate=false;
	
//	printf("\n\n TimeUpdateCauseInternet  %d %d %d \n", hh,mm,ss);
	
	
	if(hh>=12)
		sTime.am=false;
	else
		sTime.am=true;
	
	if(sTime.am)
	{
		sTime.hh=hh;
	}
	else
	{
		if(hh>12)
			sTime.hh=hh-12;
		else
			sTime.hh=hh;
	}
	
	sTime.mm=mm;
	sTime.ss=ss;
	sTime.valid=1;
}

bool TimeGetCfgDisp()
{
	if((sTime.cfg_ticks%1000)>500 || (sTime.cfg_ticks%1000)==0)
		return true;
	return false;
}






