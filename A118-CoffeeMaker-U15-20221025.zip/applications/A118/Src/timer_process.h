#ifndef _TIMER_PROCESS_
#define _TIMER_PROCESS_


void Timer_0_Init(void);
void Timer_1_Init(void);


#endif

