#ifndef _MY_RTC_H_
#define _MY_RTC_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

void MyRtcInit();

#endif



