#include "brew.h"
#include "dev.h"
#include "metrics.h"

uint16_t BrewSecondsTotal=0;
uint16_t BoldSeconds=0;
uint16_t AutoPowerOffDelaySeconds=0;


bool gbBrewRelay=false;

static eDevStatus_t eDevStatus_Pre;
static eBrewStrength_t eBrewStrength_Pre;

//	eDevStatus_Other,
//	eDevStatus_NotReadyToBrew,
//	eDevStatus_ReadyToBrew,
//	eDevStatus_Brewing,
//	eDevStatus_CoffeeReady,
//	eDevStatus_KeepWarm,
bool bBrewRelayInManage=false;


uint16_t EsoCounts=0;
uint16_t EsoCounts2_ToClear_gCleaningRequired=0;
bool gbPending_ToClear_gCleaningRequired=false;
uint16_t EsoCheckEnTicks=0;
bool gbEso_ThermostatOff=false;



void clear_eso_pra()
{
	EsoCounts=0;
	EsoCheckEnTicks=0;
//	gbEso_ThermostatOff=false;
//	gCleaningRequired=CLEANING_REQUIRED_NO;
	gCleaningRequiredLcd=CLEANING_REQUIRED_NO;
}

void BrewHandle()
{
	static bool bReloadEsoCheckEnTicks=false;
//	UpdateTimeSinceBrew(BrewSecondsTotal);
	if(eDevStatus_Pre!=eDevStatus)
	{
		eDevStatus_Pre=eDevStatus;
		switch(eDevStatus_Pre)
		{
			case eDevStatus_Brewing:
//				clear_eso_pra();
			break;
			case eDevStatus_CoffeeReady:
			case eDevStatus_KeepWarm:
			break;
			
			default:	//other status is all power off
				BrewSecondsTotal=0;
				AutoPowerOffDelaySeconds=0;
				BoldSeconds=0;
			break;
		}
	}
	
	if(eBrewStrength_Pre!=eBrewStrength)
	{
		eBrewStrength_Pre=eBrewStrength;
		BoldSeconds=0;
	}
	
	if(eDevStatus==eDevStatus_Brewing)
	{
		if(gbThermostatOff)
		{
			eDevStatus=eDevStatus_CoffeeReady;
			AutoPowerOffDelaySeconds=AUTO_POWER_OFF_DELAY_SECONDS;
		}
		else
			goto BrewHandle_gbBrewRelay_Check;
	}
	if((eDevStatus==eDevStatus_CoffeeReady) || (eDevStatus==eDevStatus_KeepWarm))
	{
		if(gbThermostatOff)
		{
			BrewSecondsTotal=0;
			BoldSeconds=0;
			if(!gbEso_ThermostatOff)
			{
				gbEso_ThermostatOff=true;
				#if DEBUG_ESO
				EsoCheckEnTicks=5;
				#else
				EsoCheckEnTicks=30;
				#endif
				bReloadEsoCheckEnTicks=true;
			}
			gbBrewRelay=true;
			bBrewRelayInManage=false;
			if(bReloadEsoCheckEnTicks && !EsoCheckEnTicks)
			{
				bReloadEsoCheckEnTicks=false;
				printf("EsoCounts2_ToClear_gCleaningRequired-->>>>>>>>>>>[%d]\n",EsoCounts2_ToClear_gCleaningRequired);
				if(EsoCounts2_ToClear_gCleaningRequired && gbPending_ToClear_gCleaningRequired)
				{
					EsoCounts2_ToClear_gCleaningRequired--;
					if(!EsoCounts2_ToClear_gCleaningRequired)
					{
						clear_eso_pra();
						gCleaningRequired=CLEANING_REQUIRED_NO;
						gbPending_ToClear_gCleaningRequired=false;
					}
				}
			}
			return;
		}
		else
		{
			goto BrewHandle_gbBrewRelay_Check;
		}
	}
	
//	goto BrewHandle_PowerOff;
//	BrewHandle_PowerOff:
	gbEso_ThermostatOff=false;
	bBrewRelayInManage=false;
	gbBrewRelay=false;
	return;
	
	BrewHandle_gbBrewRelay_Check:
	
//	if(gbEso_ThermostatOff && !EsoCheckEnTicks)
//	{
//		if(EsoCounts2_ToClear_gCleaningRequired)
//		{
//			EsoCounts2_ToClear_gCleaningRequired--;
//			if(!EsoCounts2_ToClear_gCleaningRequired)
//			{
//				clear_eso_pra();
//				gCleaningRequired=CLEANING_REQUIRED_NO;
//			}
//		}
//	}
	gbEso_ThermostatOff=false;
	if(EsoCheckEnTicks)
	{
		EsoCheckEnTicks=0;
		EsoCounts++;
//		if(EsoCounts2_ToClear_gCleaningRequired<2)
			EsoCounts2_ToClear_gCleaningRequired=1;
		
		gbMetric__Eso=true;
		MetricEsoCounts=EsoCounts;
		eDevStatus=eDevStatus_Brewing;
		if(EsoCounts>=2)
		{
			if(gCleaningRequiredLcd!=CLEANING_REQUIRED_YES)
			{
				gCleaningRequiredLcd=gCleaningRequired=CLEANING_REQUIRED_YES;
				
				gbMetric__Clean=true;
			}
			if(EsoCounts==ESO_COUNTS)
			{
				DevPowerOff();
//				eDevStatus=eDevStatus_KeepWarm;
//				AutoPowerOffDelaySeconds=AUTO_POWER_OFF_DELAY_SECONDS;
				Metrics_SetEndMethod(eMetrics_EndMethod_Error);
			}
		}
		else
		{
			AutoPowerOffDelaySeconds=0;
		}
		BrewSecondsTotal=0;
		BoldSeconds=0;
		printf("\n\n ...............EsoCounts = %d \n",EsoCounts);
	}
	bBrewRelayInManage=true;
	switch(eBrewStrength)
	{
		case eBrewStrength_Regular:
			gbBrewRelay=true;
		break;
		case eBrewStrength_Bold:
			if(BrewSecondsTotal<BOLD_RELAY_CONTINUOUSLY || BoldSeconds>=BOLD_RELAY_CYCLING_TOTAL)
			{
				gbBrewRelay=true;
				break;
			}
			if((BoldSeconds%(BOLD_RELAY_CYCLING_UNIT*2))<BOLD_RELAY_CYCLING_UNIT)
				gbBrewRelay=false;
			else
				gbBrewRelay=true;
		break;
		default:
			break;
	}
}

uint16_t TimeSinceBrew=0;
static void TimeSinceBrewHandle()
{
	static eDevStatus_t status=eDevStatus_Other;
	
	if(status!=eDevStatus)
	{
		status=eDevStatus;
		if(!(status==eDevStatus_CoffeeReady || status==eDevStatus_KeepWarm))
			TimeSinceBrew=0;
	}
	if(status==eDevStatus_CoffeeReady || status==eDevStatus_KeepWarm)
		TimeSinceBrew++;
	UpdateTimeSinceBrew(TimeSinceBrew);
}

void BrewHandleForTmrInt()
{
	static uint8_t ticks=0;
	
	if(++ticks>=100)
	{
		ticks=0;
		
		TimeSinceBrewHandle();
		
		if(EsoCheckEnTicks)
			EsoCheckEnTicks--;
		
		if(bBrewRelayInManage)
		{
			BrewSecondsTotal++;
			if(BrewSecondsTotal>=BOLD_RELAY_CONTINUOUSLY && eBrewStrength==eBrewStrength_Bold)
				BoldSeconds++;
		}
		
		if(AutoPowerOffDelaySeconds)
		{
			AutoPowerOffDelaySeconds--;
			if(AutoPowerOffDelaySeconds<=(AUTO_POWER_OFF_DELAY_SECONDS-COFFEE_READY_SECONDS))
				eDevStatus=eDevStatus_KeepWarm;
			if(!AutoPowerOffDelaySeconds)
			{
				DevPowerOff();
				Metrics_SetEndMethod(eMetrics_EndMethod_ASO);
			}
		}
	}
}










