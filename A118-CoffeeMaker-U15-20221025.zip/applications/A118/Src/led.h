#ifndef _LED_H_
#define _LED_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbWifiLost;
extern bool gbResetWiFiCredentials;


void LedInit();
void LedHandle();
void LedHandleForTmrInt();
bool LedResetWifiSearchTicks();
bool GetWifiSearchTicks();


#endif








