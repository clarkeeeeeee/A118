#ifndef _METRICS_H_
#define _METRICS_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

#define METRICS_KETTLE_CYCLE_COUNT_MAX		7300

extern bool gbMetrics__brew_start;
extern bool gbMetrics__kettle_start_time;
extern bool gbMetrics__brew_start_method;
extern bool gbMetrics__brew_mode;
extern bool gbMetrics__ready_to_brew_state;
extern bool gbMetric__Clean;
extern bool gbMetric__Eso;
extern uint16_t MetricEsoCounts;
extern bool gbMetrics__ERR_stuck_button;

extern uint16_t KettleCycleCount;
extern uint16_t KettleCycleCountBkp;
extern uint16_t BrewCycleCount;
extern uint16_t BrewCycleCountBkp;
extern uint16_t Metrics__PreSetBkp;
extern bool gbMetrics__kettle_temp_units;
extern bool gbMetrics__kettle_target_temp;
extern uint16_t Metrics__TempSet_FahrenheitBkp;
extern uint32_t Metrics__Kettle_heater_life;
extern uint32_t Metrics__kettle_relay_cycle;




typedef struct
{
	int16_t hh;
	int16_t mm;
	int16_t ss;
	bool valid;
}sMetricsRtc_t;

typedef enum
{
	eMetrics_StartMethod_manual,
	eMetrics_StartMethod_remote,
}eMetrics_StartMethod_t;

typedef enum
{
	eMetrics_EndMethod_manual,
	eMetrics_EndMethod_ASO,
	eMetrics_EndMethod_alexa,
	eMetrics_EndMethod_Error,
}eMetrics_EndMethod_t;


extern bool gbMetrics__kettle_start_method;
extern eMetrics_StartMethod_t Metrics__start_method;

extern sMetricsRtc_t sMetricsRtc;

void MetricsHandle();
void Metrics_BrewCycleCountAdd();
void MetricsHandleForTmrInt();
void Metrics_SetEndMethod(eMetrics_EndMethod_t method);
void Metrics_SetKettleLocation_BP(uint16_t temperature);
void Metrics_ReloadMetricsBusy();


#endif



