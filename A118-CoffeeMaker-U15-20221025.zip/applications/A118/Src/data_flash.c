#include "data_flash.h"
#include "fmc.h"
#include "ack_m031_ota.h"

uint32_t DataFlashBase;
bool gbDataFlashValid=false;


void DataFlash_Init(void)
{
    uint32_t i;

    SYS_UnlockReg();
    
    /* Enable FMC ISP function */
    FMC_Open();

    /* Enable Data Flash and set base address. */
//    if (set_data_flash_base(ACK_NUMICRO_EEPROM_START) < 0)
//    {
//        printf("Failed to set Data Flash base address!\n");
//        goto lexit;
//    }

    /* Read User Configuration */
    printf("  User Config 0 ......................... [0x%08x]\n", FMC_Read(FMC_CONFIG_BASE));
    printf("  User Config 1 ......................... [0x%08x]\n", FMC_Read(FMC_CONFIG_BASE+4));

    /* Read Data Flash base address */
    DataFlashBase = FMC_ReadDataFlashBaseAddr();
    printf("  Data Flash Base Address ............... [0x%08x]\n", DataFlashBase);

	if(DataFlashBase==ACK_NUMICRO_EEPROM_START)
		gbDataFlashValid=true;
lexit:

    /* Disable FMC ISP function */
    FMC_Close();

    /* Lock protected registers */
    SYS_LockReg();

    printf("\nFMC Sample Code Completed.\n");
}



static int32_t verify_data(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t u32Pattern)
{
    uint32_t    u32Addr;
    uint32_t    u32data;

    for (u32Addr = u32StartAddr; u32Addr < u32EndAddr; u32Addr += 4)
    {
        u32data = FMC_Read(u32Addr);
        if (u32data != u32Pattern)
        {
            printf("\nFMC_Read data verify failed at address 0x%x, read=0x%x, expect=0x%x\n", u32Addr, u32data, u32Pattern);
            return -1;
        }
    }
    return 0;
}

int32_t fill_data_pattern(uint32_t u32StartAddr, uint32_t u32EndAddr, uint32_t *u32Pattern)
{
    uint32_t u32Addr;

    for (u32Addr = u32StartAddr; u32Addr < u32EndAddr; u32Addr += 4,u32Pattern++)
    {
        FMC_Write(u32Addr, *u32Pattern);
    }
    return 0;
}

uint32_t TestAddr;

int32_t DataFlash_Save(uint32_t addr,uint32_t *data,uint32_t data_len)
{
	uint8_t i=0;
	
	if(!gbDataFlashValid)
		return -1;
	
	/* Unlock protected registers to operate FMC ISP function */
    SYS_UnlockReg();
	
	/* Enable FMC ISP function */
    FMC_Open();
	
	printf("\nAPROM start write =>\n");
    FMC_ENABLE_AP_UPDATE();
	
	if(addr==DataFlashBase)
	{
		for(i=0;i<(ACK_NUMICRO_EEPROM_SIZE/FMC_FLASH_PAGE_SIZE);i++)
		{
			TestAddr=DataFlashBase+FMC_FLASH_PAGE_SIZE*i;
			
			printf("\nPage 0x%x erase!\n", TestAddr);
			/* Erase page */
			FMC_Erase(TestAddr);
		
			/* Verify if page contents are all 0xFFFFFFFF */
			if (verify_data(TestAddr, TestAddr + FMC_FLASH_PAGE_SIZE, 0xFFFFFFFF) < 0)
			{
				FMC_DISABLE_AP_UPDATE();
				
				printf("\nPage 0x%x erase verify failed!\n", TestAddr);
				return -1;
			}
		}
	}
	
	/* Write test pattern to fill the whole page */
	if (fill_data_pattern(addr, addr + data_len*4, data) < 0)
	{
		FMC_DISABLE_AP_UPDATE();
		
		printf("Failed to write page 0x%x!\n", addr);
		return -1;
	}
	
	FMC_DISABLE_AP_UPDATE();
	
	printf("...Flash Save Ok.          \n");
    return 0;
}
int32_t DataFlash_Read(uint32_t addr,uint32_t *data,uint32_t data_len)
{
	uint32_t    u32Addr;
    uint32_t    u32data;

	if(!gbDataFlashValid)
		return -1;
	
	/* Unlock protected registers to operate FMC ISP function */
    SYS_UnlockReg();
	
	/* Enable FMC ISP function */
    FMC_Open();
	
	printf("\n\n read =>\n");
    FMC_ENABLE_AP_UPDATE();
	
	for (u32Addr = addr; u32Addr < addr+data_len*4; u32Addr += 4,data++)
    {
        *data = FMC_Read(u32Addr);
    }
	
	FMC_DISABLE_AP_UPDATE();
	
	printf("\r    read Passed.          \n");
    return 0;
}



