#include "lcd.h"
#include "time.h"
#include "dev.h"
#include "brew.h"
#include "self_check.h"
#include "key.h"


#define LCD_RAM_LEN		4

unsigned char LcdScanIdx=0;
unsigned char LcdRam[LCD_RAM_LEN];
unsigned char LcdRamBuf[LCD_RAM_LEN];
unsigned int LcdFullTime=POWER_ON_ALL_SHOW_TIME;


const unsigned char NBR_TAB[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

#define DEF_WORD_C		0X39
#define DEF_WORD_L		0X38
#define DEF_WORD_E		0X79
#define DEF_WORD_A		0X77
#define DEF_WORD_n		0X54
#define DEF_WORD_U		0X3e
#define DEF_WORD_P		0X73
#define DEF_WORD_S		0x6d
#define DEF_WORD_N		0x37

#define LCD_BKL(X)	PA10=X


#define LCD_SEG1(X)	PB7=X
#define LCD_SEG2(X)	PB6=X
#define LCD_SEG3(X)	PB5=X
#define LCD_SEG4(X)	PB4=X
#define LCD_SEG5(X)	PB1=X
#define LCD_SEG6(X)	PB0=X
#define LCD_SEG7(X)	PA11=X


#define LCD_COM1(X)	PB12=X
#define LCD_COM2(X)	PC14=X
#define LCD_COM3(X)	PB14=X
#define LCD_COM4(X)	PB13=X



#define LCD_COM1_DIR(X)		{if(X) GPIO_SetMode(PB, BIT12, GPIO_MODE_OUTPUT);else GPIO_SetMode(PB, BIT12, GPIO_MODE_INPUT);}
#define LCD_COM2_DIR(X)		{if(X) GPIO_SetMode(PC, BIT14, GPIO_MODE_OUTPUT);else GPIO_SetMode(PC, BIT14, GPIO_MODE_INPUT);}
#define LCD_COM3_DIR(X)		{if(X) GPIO_SetMode(PB, BIT14, GPIO_MODE_OUTPUT);else GPIO_SetMode(PB, BIT14, GPIO_MODE_INPUT);}
#define LCD_COM4_DIR(X)		{if(X) GPIO_SetMode(PB, BIT13, GPIO_MODE_OUTPUT);else GPIO_SetMode(PB, BIT13, GPIO_MODE_INPUT);}



#define NBR1_BC		LcdRamBuf[0]|=1
#define NBR2_D		LcdRamBuf[0]|=2
#define COLON		LcdRamBuf[0]|=4
#define NBR3_D		LcdRamBuf[0]|=8
#define BOLD		LcdRamBuf[0]|=16
#define NBR4_D		LcdRamBuf[0]|=32
#define REGULAR		LcdRamBuf[0]|=64


#define NBR2_E		LcdRamBuf[1]|=1
#define NBR2_C		LcdRamBuf[1]|=2
#define NBR3_E		LcdRamBuf[1]|=4
#define NBR3_C		LcdRamBuf[1]|=8
#define NBR4_E		LcdRamBuf[1]|=16
#define NBR4_C		LcdRamBuf[1]|=32
#define CUPS1_4		LcdRamBuf[1]|=64

#define NBR2_G		LcdRamBuf[2]|=1
#define NBR2_B		LcdRamBuf[2]|=2
#define NBR3_G		LcdRamBuf[2]|=4
#define NBR3_B		LcdRamBuf[2]|=8
#define NBR4_G		LcdRamBuf[2]|=16
#define NBR4_B		LcdRamBuf[2]|=32
#define PM			LcdRamBuf[2]|=64

#define NBR2_F		LcdRamBuf[3]|=1
#define NBR2_A		LcdRamBuf[3]|=2
#define NBR3_F		LcdRamBuf[3]|=4
#define NBR3_A		LcdRamBuf[3]|=8
#define NBR4_F		LcdRamBuf[3]|=16
#define NBR4_A		LcdRamBuf[3]|=32
#define AM			LcdRamBuf[3]|=64



static void lcd_ram_reload()
{
	unsigned char i=0;

	for(i=0;i<LCD_RAM_LEN;i++)
		LcdRam[i]=LcdRamBuf[i];
}

static void LcdSetComDir(unsigned char out_msk)
{
	if(out_msk&1)
		{LCD_COM1_DIR(1);}
	else
		{LCD_COM1_DIR(0);}

	if(out_msk&2)
		{LCD_COM2_DIR(1);}
	else
		{LCD_COM2_DIR(0);}

	if(out_msk&4)
		{LCD_COM3_DIR(1);}
	else
		{LCD_COM3_DIR(0);}

	if(out_msk&8)
		{LCD_COM4_DIR(1);}
	else
		{LCD_COM4_DIR(0);}
}

static void LcdSetCom(unsigned char msk)
{
	if(msk&1)
		LCD_COM1(1);
	else
		LCD_COM1(0);

	if(msk&2)
		LCD_COM2(1);
	else
		LCD_COM2(0);

	if(msk&4)
		LCD_COM3(1);
	else
		LCD_COM3(0);

	if(msk&8)
		LCD_COM4(1);
	else
		LCD_COM4(0);	
}



static void LcdSetSeg(unsigned char msk)
{
	if(msk&1)
		LCD_SEG1(1);
	else
		LCD_SEG1(0);

	if(msk&2)
		LCD_SEG2(1);
	else
		LCD_SEG2(0);

	if(msk&4)
		LCD_SEG3(1);
	else
		LCD_SEG3(0);

	if(msk&8)
		LCD_SEG4(1);
	else
		LCD_SEG4(0);

	if(msk&16)
		LCD_SEG5(1);
	else
		LCD_SEG5(0);

	if(msk&32)
		LCD_SEG6(1);
	else
		LCD_SEG6(0);

	if(msk&64)
		LCD_SEG7(1);
	else
		LCD_SEG7(0);
}


void LcdPortInit()
{
	LcdSetSeg(0);
	LcdSetCom(0);
	GPIO_SetMode(PB, BIT7, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PB, BIT6, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PB, BIT5, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PB, BIT4, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PB, BIT1, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PB, BIT0, GPIO_MODE_OUTPUT);
	GPIO_SetMode(PA, BIT11, GPIO_MODE_OUTPUT);
	LCD_COM1_DIR(1);
	LCD_COM2_DIR(1);
	LCD_COM3_DIR(1);
	LCD_COM4_DIR(1);

	GPIO_SetMode(PA, BIT10, GPIO_MODE_OUTPUT);
	LCD_BKL(0);
}

static void lcd_nbr1(unsigned char nbr)
{
	if(nbr>1 || !nbr)
		return;	
	
	NBR1_BC;
}
static void lcd_nbr2(unsigned char nbr)
{
	if(nbr>9)
		return;
	
	if(NBR_TAB[nbr]&1)
		NBR2_A;
	if(NBR_TAB[nbr]&2)
		NBR2_B;
	if(NBR_TAB[nbr]&4)
		NBR2_C;
	if(NBR_TAB[nbr]&8)
		NBR2_D;
	if(NBR_TAB[nbr]&16)
		NBR2_E;
	if(NBR_TAB[nbr]&32)
		NBR2_F;
	if(NBR_TAB[nbr]&64)
		NBR2_G;
}
static void lcd_nbr2_word(unsigned char word)
{
	if(word&1)
		NBR2_A;
	if(word&2)
		NBR2_B;
	if(word&4)
		NBR2_C;
	if(word&8)
		NBR2_D;
	if(word&16)
		NBR2_E;
	if(word&32)
		NBR2_F;
	if(word&64)
		NBR2_G;
}
static void lcd_nbr3(unsigned char nbr)
{
	if(nbr>9)
		return;	
	
	if(NBR_TAB[nbr]&1)
		NBR3_A;
	if(NBR_TAB[nbr]&2)
		NBR3_B;
	if(NBR_TAB[nbr]&4)
		NBR3_C;
	if(NBR_TAB[nbr]&8)
		NBR3_D;
	if(NBR_TAB[nbr]&16)
		NBR3_E;
	if(NBR_TAB[nbr]&32)
		NBR3_F;
	if(NBR_TAB[nbr]&64)
		NBR3_G;
}
static void lcd_nbr3_word(unsigned char word)
{
	if(word&1)
		NBR3_A;
	if(word&2)
		NBR3_B;
	if(word&4)
		NBR3_C;
	if(word&8)
		NBR3_D;
	if(word&16)
		NBR3_E;
	if(word&32)
		NBR3_F;
	if(word&64)
		NBR3_G;
}

static void lcd_nbr4(unsigned char nbr)
{
	if(nbr>9)
		return;	
	
	if(NBR_TAB[nbr]&1)
		NBR4_A;
	if(NBR_TAB[nbr]&2)
		NBR4_B;
	if(NBR_TAB[nbr]&4)
		NBR4_C;
	if(NBR_TAB[nbr]&8)
		NBR4_D;
	if(NBR_TAB[nbr]&16)
		NBR4_E;
	if(NBR_TAB[nbr]&32)
		NBR4_F;
	if(NBR_TAB[nbr]&64)
		NBR4_G;
}




static void lcd_nbr4_word(unsigned char word)
{
	if(word&1)
		NBR4_A;
	if(word&2)
		NBR4_B;
	if(word&4)
		NBR4_C;
	if(word&8)
		NBR4_D;
	if(word&16)
		NBR4_E;
	if(word&32)
		NBR4_F;
	if(word&64)
		NBR4_G;
}

static void lcd_nbr12(unsigned char nbr)
{
	if(nbr>19)
		return;
	
	lcd_nbr1(nbr/10);
	lcd_nbr2(nbr%10);
}
static void lcd_nbr34(unsigned char nbr)
{
	if(nbr>99)
		return;
	
	lcd_nbr3(nbr/10);
	lcd_nbr4(nbr%10);
}

static void lcd_test()
{
	lcd_nbr1(1);
	lcd_nbr2(2);
	lcd_nbr3(3);
	lcd_nbr4(4);
}

static void lcd_full()
{
	unsigned char i=0;

	for(i=0;i<LCD_RAM_LEN;i++)
		LcdRamBuf[i]=0xff;
}
static void lcd_clear()
{
	unsigned char i=0;

	for(i=0;i<LCD_RAM_LEN;i++)
		LcdRamBuf[i]=0;
}



static uint16_t LcdTicks_Nbr1234=0;
static void lcd_TimeNotValid()
{
	if(LcdTicks_Nbr1234>100)
	{
		NBR2_G;
		NBR3_G;
		NBR4_G;
	}
	COLON;
}
static void lcd_TimeValid()
{
	if(LcdTicks_Nbr1234>100)
	{
		COLON;
	}
	lcd_nbr12(sTime.hh);
	lcd_nbr34(sTime.mm);
//	lcd_nbr12(sTime.mm%10);
//	lcd_nbr34(sTime.ss);
	if(sTime.am)
		AM;
	else
		PM;
}
static void lcd_TimeCfg()
{
	if(!sTime.cfg_idx)
		return;
	
	COLON;
	if(sTime.am)
		AM;
	else
		PM;
	if(sTime.cfg_idx==1)
	{
		if(TimeGetCfgDisp())
			lcd_nbr12(sTime.hh);
		lcd_nbr34(sTime.mm);
	}
	if(sTime.cfg_idx==2)
	{
		if(TimeGetCfgDisp())
			lcd_nbr34(sTime.mm);
		lcd_nbr12(sTime.hh);
	}
}

typedef enum
{
	eLcdNbr1234_TimeNotValid,
	eLcdNbr1234_TimeValid,
	eLcdNbr1234_TimeCfg,
	eLcdNbr1234_None,
}eLcdNbr1234_t;

eLcdNbr1234_t eLcdNbr1234;
eLcdNbr1234_t eLcdNbr1234Bkp;

void ReloadLcdTicks_Nbr1234()
{
	switch(eLcdNbr1234)
	{
		case eLcdNbr1234_TimeNotValid:
		case eLcdNbr1234_TimeValid:
			LcdTicks_Nbr1234=200;
		break;
		
		case eLcdNbr1234_TimeCfg:
			LcdTicks_Nbr1234=100;
		break;
		
		default:
			break;
	}
}

static void lcd_brew_strength()
{
	if(eBrewStrength==eBrewStrength_Regular)
		REGULAR;
	if(eBrewStrength==eBrewStrength_Bold)
		BOLD;
}



//#define DEF_WORD_C		0X39
//#define DEF_WORD_L		0X38
//#define DEF_WORD_E		0X79
//#define DEF_WORD_A		0X77
//#define DEF_WORD_n		0X54
static uint16_t lcd_clean_ticks=0;
static uint16_t lcd_clean_step=0;
static bool lcd_clean()
{
	bool b_ret=true;
	
	if(++lcd_clean_ticks>=1700)
	{
		lcd_clean_ticks=0;
	}
	lcd_clean_step=lcd_clean_ticks/100;
	
	switch(lcd_clean_step)
	{
		case 0:
			lcd_nbr4_word(DEF_WORD_C);
		break;
		case 1:
			lcd_nbr3_word(DEF_WORD_C);
			lcd_nbr4_word(DEF_WORD_L);
		break;
		case 2:
			lcd_nbr2_word(DEF_WORD_C);
			lcd_nbr3_word(DEF_WORD_L);
			lcd_nbr4_word(DEF_WORD_E);
		break;
		case 3:
			lcd_nbr2_word(DEF_WORD_L);
			lcd_nbr3_word(DEF_WORD_E);
			lcd_nbr4_word(DEF_WORD_A);
		break;
		case 4:
			lcd_nbr2_word(DEF_WORD_E);
			lcd_nbr3_word(DEF_WORD_A);
			lcd_nbr4_word(DEF_WORD_N);
		break;
		case 5:
			lcd_nbr2_word(DEF_WORD_A);
			lcd_nbr3_word(DEF_WORD_N);
		break;
		case 6:
			lcd_nbr2_word(DEF_WORD_N);
		break;
		
		default:
			b_ret=false;
		break;
	}
	
	
	return b_ret;
}



static uint16_t lcd_self_check_ticks=0;
static uint16_t lcd_self_check_step=1;
static void lcd_self_check()
{
	if(++lcd_self_check_ticks>=70)
	{
		lcd_self_check_ticks=0;
		if(++lcd_self_check_step>7)
			SelfCheckStepsPlus();
	}
	
	if(lcd_self_check_step)
		lcd_nbr1(1);
	if(lcd_self_check_step>1)
		lcd_nbr2(8);
	if(lcd_self_check_step>2)
		COLON;
	if(lcd_self_check_step>3)
		lcd_nbr3(8);
	if(lcd_self_check_step>4)
		lcd_nbr4(8);
	if(lcd_self_check_step>5)
		AM;
	if(lcd_self_check_step>6)
		PM;
}
static void lcd_self_check_regular()
{
	if(lcd_self_check_ticks<50)
		REGULAR;
	if(++lcd_self_check_ticks>=100)
		SelfCheckStepsPlus();
}
static void lcd_self_check_bold()
{
	if(lcd_self_check_ticks<50)
		BOLD;
	if(++lcd_self_check_ticks>=100)
		SelfCheckStepsPlus();
}
static void lcd_self_check_version()
{
	if(lcd_self_check_ticks<100)
	{
		lcd_nbr2_word(DEF_WORD_U);
		lcd_nbr34(FIRMWARE_VERSION);
	}
	lcd_self_check_ticks++;
}
uint8_t LcdTest=0;

void LcdHandle()
{
	static uint8_t step=0xff;
	
	lcd_clear();
	
//	gCleaningRequired=1;
	
	if(gbSelfCheckKeysEn || SelfCheckRetStatus())
	{
		if(!SelfCheckRetStatus())
		{
			LCD_BKL(0);
			goto Step_lcd_ram_reload;
		}
		
		if(step!=SelfCheckRetSteps())
		{
			step=SelfCheckRetSteps();
			lcd_self_check_ticks=0;
		}
		
		switch(step)
		{
			case 0:
				lcd_full();
				LCD_BKL(1);
			break;
			case 1:
				LCD_BKL(0);
			break;
			case 2:
				LCD_BKL(1);
				lcd_self_check_version();
			break;
			case 3:
				LCD_BKL(0);
			break;
//			case 5:
//				LCD_BKL(1);
//				lcd_self_check();
//			break;
//			case 6:
//				LCD_BKL(1);
//				lcd_self_check_regular();
//			break;
//			case 7:
//				LCD_BKL(1);
//				lcd_self_check_bold();
//			break;
//			case 8:
//				LCD_BKL(1);
//				lcd_self_check_version();
//			break;
			case 4:
				if(SelfCheckKeyCode)
				{
					LCD_BKL(1);
					lcd_nbr2(SelfCheckKeyCode);
					lcd_nbr3(SelfCheckKeyCode);
					lcd_nbr4(SelfCheckKeyCode);
				}
				else
					LCD_BKL(0);
			break;
				
			case 5:
				LCD_BKL(1);
				if(gbSelfCheckRelayOn)
					break;
				if(SelfCheckErrorCode)
				{
					lcd_nbr2_word(DEF_WORD_E);
					lcd_nbr3_word(DEF_WORD_C);
					lcd_nbr4(SelfCheckErrorCode);
					break;
				}
				lcd_nbr2_word(DEF_WORD_P);
				lcd_nbr3_word(DEF_WORD_A);
				lcd_nbr4_word(DEF_WORD_S);
			break;
			
			default:
				break;
		}
		goto Step_lcd_ram_reload;
	}
	
	
	
	
	if(gKeyStuck)
	{
		lcd_nbr2_word(DEF_WORD_E);
		LCD_BKL(1);
		lcd_nbr34(gKeyStuck);
		goto Step_lcd_ram_reload;
	}
	
	if(LcdFullTime)
	{
		lcd_full();
		LCD_BKL(1);
		goto Step_lcd_ram_reload;
	}

	
	
	if(gCleaningRequiredLcd==CLEANING_REQUIRED_YES)
	{
		LCD_BKL(1);
		if(lcd_clean())
			goto LcdHandle_Other;
		else
			goto time_show;
	}
	else
	{
		lcd_clean_ticks=0;
		lcd_clean_step=0;
	}
	
	if(sTime.cfg_idx)
	{
		eLcdNbr1234=eLcdNbr1234_TimeCfg;
		if(eLcdNbr1234Bkp!=eLcdNbr1234)
			ReloadLcdTicks_Nbr1234();
		eLcdNbr1234Bkp=eLcdNbr1234_TimeCfg;
		lcd_TimeCfg();
		LCD_BKL(1);
		goto LcdHandle_Other;
	}
	
	
	
	time_show:
	if(!gbTimeShow)
	{
		goto LcdHandle_NoTimeShow;
	}
	
	if(sTime.valid)
	{
		eLcdNbr1234=eLcdNbr1234_TimeValid;
		if(eLcdNbr1234Bkp!=eLcdNbr1234)
			ReloadLcdTicks_Nbr1234();
		eLcdNbr1234Bkp=eLcdNbr1234;
		lcd_TimeValid();
		LCD_BKL(1);
		goto LcdHandle_Other;
	}
	if(!sTime.valid)
	{
		if(sTime.invalid_ticks>=(5*60*100))
			goto LcdHandle_Other;
		
		LCD_BKL(1);
		eLcdNbr1234=eLcdNbr1234_TimeNotValid;
		if(eLcdNbr1234Bkp!=eLcdNbr1234)
			ReloadLcdTicks_Nbr1234();
		eLcdNbr1234Bkp=eLcdNbr1234;
		lcd_TimeNotValid();
		goto LcdHandle_Other;
	}
	
	
	LcdHandle_NoTimeShow:
//	if(gbPower)
		LCD_BKL(1);
//	else
//		LCD_BKL(0);

	LcdHandle_Other:
	lcd_brew_strength();
//	if(gbBrewRelay)
//		CUPS1_4;
	
	Step_lcd_ram_reload:
	lcd_ram_reload();
}

void LcdHandleForTmrInt()
{
	if(LcdFullTime)
		LcdFullTime--;
	if(LcdTicks_Nbr1234)
		LcdTicks_Nbr1234--;
	else
		ReloadLcdTicks_Nbr1234();
}

void LcdScan(void)	
{   
	unsigned char j;

	j = LcdScanIdx >> 1;        //COMx

	if(j >=LCD_RAM_LEN)
		j=0;

	LcdSetComDir(0);       		//ȫ��COM�������, COMΪ�е��ѹ
	if(LcdScanIdx & 1)          //����ɨ��
	{   
		LcdSetSeg(~LcdRam[j]);	//seg�����	com�����
		LcdSetCom(0xff);
	}
	else						//����ɨ��
	{   
		LcdSetSeg(LcdRam[j]);	//seg�����	com�����
		LcdSetCom(0);
	}
	LcdSetComDir(1<<j);		
	if(++LcdScanIdx >= 8)	
		LcdScanIdx = 0;   
}




















































