#!/usr/bin/env python3
# Copyright 2018-2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# You may not use this file except in compliance with the terms and conditions set forth in the
# accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
# DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
# THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.

# Setup file for Arduino. Copies Alexa Connect Kit Device SDK files into place such that ACK Host MCU
# sample applications become available as example sketches in the Arduino IDE.
#
# An obvious approach in the Arduino idiom might have been to create a single ACK Device SDK library, and have each
# sample application be an example sketch under the single common library. However, this isn't possible because the
# ACK Device SDK requires per-application compile-time configuration of its 'common' parts; each HMCU application
# tailors the common parts of the SDK to its own use case, at build time. That's incompatible with what the Arduino IDE
# library mechanism expects. (Reference: https://arduino.github.io/arduino-cli/latest/library-specification.)
#
# Instead, each ACK sample application becomes its own library with a single example sketch. The directory structure
# for each of those is as follows (under the Arduino library root), using HelloWorld as an example:
#
#   AlexaConnectKit_HelloWorld
#      library.properties
#      src/
#         ACK_HelloWorld.h
#      examples/
#         HelloWorld/
#            src/
#              (all common source files)
#            HelloWorld.ino
#            (other application-specific files)
#
# ACK_HelloWorld.h is empty, just a dummy file to satisfy the Arduino IDE's library management functionality.
#
# "All common source files" means all *.c/*.h from under core, include, external/nanopb, etc., flattened. Flattened
# means that all files in the SDK + application go into that one target directory regardless of original directory
# structure in the repo.
#
# HelloWorld.ino is just HelloWorld.c from the application, renamed. Required because every Arduino sketch must have
# a .ino file. Other source files from applications/HelloWorld in the repo are copied next to the .ino file in the
# target.
#
# Finally, all source files have any #include with a subdirectory changed to remove the subdirectory. For example
#
#   #include "details/ack_types.h"
#
# is changed to
#
#   #include "ack_types.h"
#
# Because all files are in the flat directory, the subdirectory in the #include wouldn't work without this change.
#
# App-specific files (in the root of the example's directory) have their #includes changed to e.g.
#
#   #include "src/ack.h"

import argparse
import glob
import os.path
import platform
import re
import shutil
import sys

# Require python3.
if sys.version_info < (3, 6):
    print("Python 3.6 required.")
    sys.exit(1)

class SetupException(Exception):
    def __init__(self, message):
        super().__init__(message)

class Setup:

    # Prefix for the name of each library under the Arduino library root.
    _ACK_LONG_NAME_PREFIX = "AlexaConnectKit_"

    # Patterns for glob of files (relative to ASDK-HMCU repo root) containing source files common to all sketeches.
    _COMMON_SOURCE_FILES_PATTERNS = \
    [
        "core/**",
        "external/nanopb/pb*",
        "include/**",
        "user/*.c",
        "user/platform/arduino/*.cpp"
    ]

    _ACK_USER_CONFIG_HEADER_FILE_NAME = "ack_user_config.h"

    _LIBRARY_SRC_SUBDIR_NAME = "src"
    _EXAMPLE_SRC_SUBDIR_NAME = "src"

    def __init__(
        self,
        *,
        only = None,
        altTargetRoot = None,
        altSourceRoot = None,
        quiet = False,
        force = False):

        repoRoot = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../../.."))

        # Application sources.
        if altSourceRoot is None:
            sourceRoot = os.path.join(repoRoot, "applications")
        else:
            sourceRoot = altSourceRoot
        if only is None:
            self._appNames = [os.path.basename(dir.rstrip(os.sep))
                for dir in glob.glob(os.path.join(sourceRoot, "*" + os.sep))]
        else:
            # Only want one.
            self._appNames = [ only ]

        # Target.
        targetRoot = altTargetRoot
        if targetRoot is None:
            homeDir = os.path.expanduser("~")
            if platform.system() == 'Windows':
                targetRoot = os.path.join(homeDir, "documents", "Arduino")
            elif platform.system() == 'Darwin': # Mac
                targetRoot = os.path.join(homeDir, "Documents", "Arduino")
            else:
                targetRoot = os.path.join(homeDir, "Arduino")

        self._quiet = quiet
        self._force = force
        self._repoRoot = repoRoot
        self._sourceRoot = sourceRoot
        self._targetRoot = targetRoot

    def Run(self):

        # Make sure we have valid source and target.
        self._ValidateSources()
        self._ValidateTarget()

        commonSourceFiles = self._FindCommonSourceFiles()

        if not self._quiet:
            print(f"Installing to directory '{self._TargetLibrariesRoot()}'...")

        for appName in self._appNames:
            if not self._quiet:
                print(appName)

            appSourceDir = self._ApplicationSourceDir(appName)
            targetLibraryDir = self._TargetLibraryDir(appName)

            self._CreateLibrary(targetLibraryDir, appName)
            self._CreateExample(commonSourceFiles, appSourceDir, targetLibraryDir, appName)            

    # Returns a list of directories containing applications to install.
    # Throws a SetupException if at least one of those directories doesn't exist.
    def _ValidateSources(self):

        if len(self._appNames) == 0:
            # This means we were given a path with no directories in it, or possibly that the repo
            # is corrupt (has no directories under the applications directory).
            raise SetupException(f"No application directories found at '{self._sourceRoot}'.")

        # Check each path to see if it exists. This really only catches a bad argument to --only,
        # because in other cases self._appDirs contains the directories we found with glob.glob().
        for appName in self._appNames:
            appDir = self._ApplicationSourceDir(appName)
            if not os.path.isdir(appDir):
                raise SetupException(f"No application directory found at '{appDir}'.")

    # Validates that the target root exists. If the target root doesn't exist, throws a SetupException.
    # Also throws SetupException if any target directories exist, unless force is set.
    def _ValidateTarget(self):
        if not os.path.isdir(self._targetRoot):
            raise SetupException(f"Arduino documents directory '{self._targetRoot}' not found.")

        if not self._force:
            for appName in self._appNames:
                targetDir = self._TargetLibraryDir(appName)
                if os.path.isdir(targetDir):
                    raise SetupException(f"Directory '{targetDir}' exists; save and remove before running this script.")

    # Builds a list of all files in the common part of the SDK. Uses glob to do recursive wildcard searches on a
    # hardcoded set of patterns.
    # Returns a list of full file paths.
    def _FindCommonSourceFiles(self):
        sourceFiles = set()
        sourcePaths = []

        for pattern in Setup._COMMON_SOURCE_FILES_PATTERNS:
            for path in glob.glob(os.path.join(self._repoRoot, pattern), recursive = True):
                # Ensure there are no duplicate filenames, which would clobber each other when flattened.
                file = os.path.basename(path)
                assert file not in sourcePaths
                sourceFiles.add(file)

                sourcePaths.append(path)

        return sourcePaths

    # Creates the Arduino library structure, including the required library.properties, and a dummy header file
    # representing the library itself.
    def _CreateLibrary(self, targetLibraryDir, appName):
        # Create library.properties.
        libraryPropertiesLines = \
            [
                f"name={Setup._ACK_LONG_NAME_PREFIX}{appName}\n",
                "version=0.0.0\n",
                "author=Alexa Connect Kit\n",
                "maintainer=Alexa Connect Kit <ack-apply@amazon.com>\n",
                f"sentence=Alexa Connect Kit {appName} sample application.\n"
                "paragraph=A sample application demonstrating how to use Alexa Connect Kit.\n",
                "url=https://developer.amazon.com/en-US/alexa/devices/connected-devices/"
                    + "development-resources/alexa-connect-kit\n"
            ]
        Setup._EnsureDirectory(targetLibraryDir)
        with open(os.path.join(targetLibraryDir, "library.properties"), "w") as f:
            f.writelines(libraryPropertiesLines)

        # Create dummy library header.
        srcPath = os.path.join(targetLibraryDir, Setup._LIBRARY_SRC_SUBDIR_NAME)
        Setup._EnsureDirectory(srcPath)
        with open(os.path.join(srcPath, "ACK_" + appName + ".h"), "w") as f:
            f.write("// All code for this library is in the example sketch.\n")

    # Creates an example sketch under an Arduino library. This involves copying files and fixing up #include directives
    # to refer to files in their locations in the example sketch (the directory structure of the example sketch is
    # different from the structure in the repo).
    def _CreateExample(self, commonSourceFiles, appSourceDir, targetLibraryDir, appName):
        exampleFlatDir = os.path.join(targetLibraryDir, "examples", appName)
        exampleSrcDir = os.path.join(exampleFlatDir, Setup._EXAMPLE_SRC_SUBDIR_NAME)
        Setup._EnsureDirectory(exampleSrcDir)

        appCFile = appName + ".c"

        # Copy each common source to the src directory within the flat target dir.
        Setup._CopyFilesToFlat(commonSourceFiles, exampleSrcDir)

        # Copy each application source files to the flat target dir.
        # The main app .c file must be renamed to .ino, so it's excluded here.
        Setup._CopyFilesToFlat(glob.glob(os.path.join(appSourceDir, "*.h")), exampleFlatDir)
        Setup._CopyFilesToFlat(glob.glob(os.path.join(appSourceDir, "*.c")), exampleFlatDir, excludeBasename = appCFile)

        # Copy main app .c file to .ino in target.
        Setup._CopyOneFile(os.path.join(appSourceDir, appCFile), os.path.join(exampleFlatDir, appName + ".ino"))

        # Fix up #include directives to deal with the flat directory structure we imposed.
        exampleFlatDirFilePaths = [p for p in glob.glob(os.path.join(exampleFlatDir, "*")) if os.path.isfile(p)]
        exampleSrcDirFilePaths = [p for p in glob.glob(os.path.join(exampleSrcDir, "*")) if os.path.isfile(p)]
        exampleSrcDirBasenames = set([os.path.basename(path) for path in exampleSrcDirFilePaths])

        self._FlattenIncludes(exampleSrcDirFilePaths, exampleSrcDirBasenames)
        self._FlattenIncludes(exampleFlatDirFilePaths, exampleSrcDirBasenames, prefix = Setup._EXAMPLE_SRC_SUBDIR_NAME)

        # Create a file in the flat common src dir to pull in the one in the flat dir.
        with open(os.path.join(exampleSrcDir, Setup._ACK_USER_CONFIG_HEADER_FILE_NAME), "w") as f:
            f.write(f"#include \"../{Setup._ACK_USER_CONFIG_HEADER_FILE_NAME}\"\n")

    # Fixes up #include directives so that they reference files in their locations in the sketch, which is different
    # from the way directories are structured in the repo.
    def _FlattenIncludes(self, paths, basenames, *, prefix = None):
        # Regex that matches #include lines. The string between the double quotes or angle brackets consists of
        # ascii alphanumeric characters plus dot and forward slash. Capture that string for later use.
        pattern = re.compile(r"\s*#include\s+[\"<]([\w/.]+)[\">]\s+")

        prefix = (prefix + '/') if isinstance(prefix, str) else ""

        for path in paths:
            with open(path, "r") as f:
                lines = f.readlines()

            newLines = []
            changed = False

            for line in lines:
                # Assume this line needs no changes.
                newLine = line

                # If the line is a #include, and the included file is one of ours (as opposed to say a system file),
                # change it to reference the same file but in the flattened directory, and always using quotes
                # instead of angle brackets. The former is required because we put all files in a single directory,
                # and the latter is required because using angle brackets confuses the Arduino IDE.
                m = pattern.match(line)
                if m is not None:
                    basename = os.path.basename(m[1])
                    if basename in basenames:
                        newLine = f"#include \"{prefix}{basename}\"\n"
                        changed = True

                newLines.append(newLine)

            if changed:
                with open(path, "w") as f:
                    f.writelines(newLines)

    # Forms the path to a directory containing an application.
    def _ApplicationSourceDir(self, appName):
        return os.path.join(self._sourceRoot, appName)

    # Forms the path to a directory to contain an Arduino library.
    def _TargetLibraryDir(self, appName):
        return os.path.join(self._TargetLibrariesRoot(), Setup._ACK_LONG_NAME_PREFIX + appName)

    # Forms the path to the Arduino document libraries directory.
    def _TargetLibrariesRoot(self):
        return os.path.join(self._targetRoot, "libraries")

    # Ensures that a directory exists. The directory can be multi-level; intermediate ones along the path are
    # created as needed.
    # Throws an exception if the operation fails.
    @staticmethod
    def _EnsureDirectory(path):
        try:
            os.makedirs(path, exist_ok = True)
        except OSError as e:
            raise SetupException(f"Unable to create directory '{path}': {str(e)}.")

    # Copies a set of files named by full paths to a single target directory. The original directory structure
    # is not preserved; all files are copied directly into the single target directory.
    # Throws an exception upon failure.
    @staticmethod
    def _CopyFilesToFlat(sourcePaths, targetDir, *, excludeBasename = None):
        for sourcePath in sourcePaths:
            if os.path.isfile(sourcePath):
                basename = os.path.basename(sourcePath)
                if basename != excludeBasename:
                    Setup._CopyOneFile(sourcePath, os.path.join(targetDir, basename))

    # Copies one file.
    # Throws an exception upon failure.
    @staticmethod
    def _CopyOneFile(source, target):
        try:
            shutil.copy2(source, target)
        except OSError as e:
            raise SetupException(f"Unable to copy '{source}' to '{target}': {str(e)}.")
        

# Entry point when invoked stand-alone.
if __name__ == '__main__':
    Parser = argparse.ArgumentParser(description = "Installs ACK applications into the Arduino IDE")
    Parser.add_argument("--only", metavar = "APPLICATIONNAME", help = "Install one ACK application")
    Parser.add_argument("--nopause", dest = "pause", default = True, action = "store_false",
        help = "Suppress pause for enter when complete")
    Parser.add_argument("--quiet", action = "store_true", help = "Quieter operation")
    Parser.add_argument("--force", action = "store_true", help = "Allow installing into existing directories")
    Parser.add_argument("--targetroot", help = "Alternate location of target Arduino documents root")
    Parser.add_argument("--sourceroot", help = "Alternate location of Arduino applications source root")

    args = Parser.parse_args()

    setup = Setup(
        only = args.only,
        altTargetRoot = args.targetroot,
        altSourceRoot = args.sourceroot,
        quiet = args.quiet,
        force = args.force)

    success = True
    try:
        setup.Run()
    except SetupException as e:
        print(str(e))
        success = False

    if success and not args.quiet:
        print("Success. Restart your Arduino IDE and look in the File->Examples menu for examples "
            f"starting with \"{Setup._ACK_LONG_NAME_PREFIX}\".")

    if args.pause:
        input("Press [ENTER] to exit...")

    sys.exit(0 if success else 1)