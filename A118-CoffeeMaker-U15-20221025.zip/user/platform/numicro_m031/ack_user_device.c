/*
 * Copyright 2018-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * You may not use this file except in compliance with the terms and conditions set forth in the
 * accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
 * DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
 */

/*
    Default implementations for ACK_UserXxx routines.

    All implementations are surrounded by #ifndef ACK_NO_ACKUSER_xxx. This allows Amazon-supplied
    ACK Host MCU sample applications to selectively replace implementations on a per-application basis.

    You can directly replace the implementations in this file, or #define ACK_NO_ACKUSER_xxx in
    ack_user_config.h and put your implementations in a different source file.
 */

#include "ack.h"
#include "ack_user_config.h"
#include "ack_user_device.h"
#include "ack_logging.h"
#include <stdbool.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef ACK_NO_ACKUSER_GETFIRMWAREVERSION

// Returns the version of your firmware. This can be any 64-bit value meaningful for your firmware
// versioning scheme.
const char *pMonth[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
const char Date[12] = __DATE__;
static void GetCompileDate(uint8_t *Year, uint8_t *Month, uint8_t *Day)
{
    uint8_t i;
    for(i = 0; i < 12; i++)
    {
        if( memcmp(Date, pMonth[i], 3) == 0 )
        {
            *Month = i + 1;
            break;
        }
    }
    *Year = (uint8_t)atoi(Date + 9);
    *Day = (uint8_t)atoi(Date + 4);
}

static void GetCompileTime(uint8_t *Hour, uint8_t *Minute, uint8_t *Second)
{
    const char Time[12] = __TIME__;
    uint32_t u32Hour, u32Minute, u32Second;
    sscanf(Time, "%d:%d:%d", &u32Hour, &u32Minute, &u32Second );
    *Hour		= u32Hour;
    *Minute	= u32Minute;
    *Second	= u32Second;
}

static void GetCompileDateTime(uint64_t* pu64DateTime)
{
    uint8_t* pu8DateTime = (uint8_t*) pu64DateTime;
    GetCompileTime(pu8DateTime+2, pu8DateTime+1, pu8DateTime);
    GetCompileDate(pu8DateTime+5, pu8DateTime+4, pu8DateTime+3);
}

// Returns the version of your firmware. This can be any 64-bit value meaningful for your firmware
// versioning scheme.
uint64_t ACKUser_GetFirmwareVersion(void)
{
    // Use a simple number for illustrative purposes. This can be any value that makes sense for your
    // firmware versioning scheme.
    uint64_t u64BuildTime=1;
    //GetCompileDateTime(&u64BuildTime);
    u64BuildTime = 0x20220714140000; // 0x20210317000100 , 0x20210414000100 , 0x20210425000100
    ACK_DEBUG_PRINT_I("%s %s 0x%014" PRIx64 "", __DATE__, __TIME__, u64BuildTime );
    return u64BuildTime;
}

#endif // ndef ACK_NO_ACKUSER_GETFIRMWAREVERSION

#ifndef ACK_NO_ACKUSER_DOESUSERWANT


#define USER_INITIATED_USER_GUIDED_SETUP 1
#define USER_INITIATED_FACTORY_RESET 2
static uint8_t sg_lifecyclePending = 0;
static bool DoesUserWantLifecycleAction(unsigned userInitiated);

void Alexa_InitiateFactoryReset(void)
{
    sg_lifecyclePending = USER_INITIATED_FACTORY_RESET;
}

void Alexa_InitiateUserGuidedSetup(void)
{
    // Factory reset takes precedence.
    ACK_STATIC_ASSERT(USER_INITIATED_USER_GUIDED_SETUP < USER_INITIATED_FACTORY_RESET);
//    if (sg_lifecyclePending < USER_INITIATED_USER_GUIDED_SETUP)
    {
        sg_lifecyclePending = USER_INITIATED_USER_GUIDED_SETUP;
    }
}

// Returns a value to HMCU Reference Implementation Core indicating whether the user has performed the
// magic keypress to initiate factory reset.
bool ACKUser_DoesUserWantFactoryReset(void)
{
    return DoesUserWantLifecycleAction(USER_INITIATED_FACTORY_RESET);
}

// Returns a value to HMCU Reference Implementation Core indicating whether the user has performed the
// magic keypress to initiate setup.

extern bool TestUgs;

bool ACKUser_DoesUserWantUserGuidedSetup(void)
{
	
	return DoesUserWantLifecycleAction(USER_INITIATED_USER_GUIDED_SETUP);
}
// Returns a value to HMCU Reference Implementation Core indicating whether the user has performed the
// magic keypress to submit logs. The smart plug has no such keypress, so just return false.
bool ACKUser_DoesUserWantToSubmitLogs(void)
{
    return false;
}

static bool DoesUserWantLifecycleAction(unsigned userInitiated)
{
    bool userWants;

    userWants = (sg_lifecyclePending == userInitiated);

    if (userWants)
    {
        sg_lifecyclePending = 0;
    }

    return userWants;
}

// The manner in which a user initiates factory reset is highly device-specific. For your product to
// support factory reset, change this placeholder to return a value based on your device-specific
// factory reset initiation mechanism (such as the user entering a certain keystroke on the device's
// front panel keypad, etc.).
//extern int g_bDoRestoreFactorySetting;
//bool ACKUser_DoesUserWantFactoryReset(void)
//{
//    return g_bDoRestoreFactorySetting;
//}

//// The manner in which a user initiates user-guided setup is highly device-specific. For your product to
//// support user-guided setup, change this placeholder to return a value based on your device-specific
//// user-guided setup initiation mechanism (the user presses and holds a specific button, or enters a
//// certain keystroke on a keypad, etc.).
//extern bool g_bDoUserGuidedSetup;
//bool ACKUser_DoesUserWantUserGuidedSetup(void)
//{
//    // liusj 20210209 modify
//    return g_bDoUserGuidedSetup; // false;
//}

//// The manner in which a user initiates log submission is highly device-specific. For your product to
//// support submitting logs, change this placeholder to return a value based on your device-specific
//// log submission initiation mechanism (the user presses and holds a specific button, or enters a
//// certain keystroke on a keypad, etc.).
//bool ACKUser_DoesUserWantToSubmitLogs(void)
//{
//    return false;
//}

#endif // ndef ACK_NO_ACKUSER_DOESUSERWANT

#ifndef ACK_NO_ACKUSER_ERASEUSERSETTINGS

// Erase persisted user settings.
// In a production device, replace this function with your own implementation.
void ACKUser_EraseUserSettings(void)
{
    ACK_DEBUG_PRINT_I("Erasing user data.");

    // Erase all persisted user settings stored on the device.
}

#endif // ndef ACK_NO_ACKUSER_ERASEUSERSETTINGS

#ifndef ACK_NO_ACKUSER_ONLIFECYCLESTATECHANGE

// Placeholder for user-supplied routine that in production would update user-facing display elements
// relating to lifecycle and connectivity state. For example, lighting a "connected to Alexa" LED,
// or flashing an LED during factory reset, or flashing a clock when in setup mode.

#include "connect.h"
extern bool gbSelfCheckGetModuleInf;
extern bool gbUgsWait;
extern int32_t gUgsWaitCounts;
int16_t PreCountsToUgs=0;
void ACKUser_OnLifecycleStateChange(void)
{
//#if defined(ACK_DEBUG_PRINT_LEVEL) && (ACK_DEBUG_PRINT_LEVEL >= ACK_DEBUG_PRINT_LEVEL_INFO)
    const char* pStateName = NULL;
    bool anyActive = false;
	
	static bool ReUgs=false;
	
//	if(ACK_LifecycleState!=ACK_LIFECYCLE_INITIAL && !gbSelfCheckGetModuleInf)
//	{
//		gbSelfCheckGetModuleInf=true;
//		printf("\n\n ...............gbSelfCheckGetModuleInf \n");
//	}
	
	if((gUgsWaitCounts>0) && ACK_LifecycleState==ACK_LIFECYCLE_BOOTED)
	{
		gUgsWaitCounts=0;
		ReUgs=true;
		printf("\n\n\n>>>>>>>>>>>>>>>>>clear gUgsWaitCounts \n\n\n");
	}
	if(ReUgs && ACK_LifecycleState>ACK_LIFECYCLE_FACTORY_RESET_IN_PROGRESS)
	{
		ReUgs=false;
		PreCountsToUgs=300;
//		sg_lifecyclePending = USER_INITIATED_USER_GUIDED_SETUP;
		printf("\n\n\n>>>>>>>>>>>>>>>>>set PreCountsToUgs 300 \n\n\n");
	}
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_IN_SETUP_MODE)
		gbModuleInSetupMode=false;
	
	if(PreCountsToUgs==0 && (ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA))
	{
		gbKeyUgsEn=false;
	}
	
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
	{
		gbKeyFrsEn=false;
	}
	
	
    // Setup is handled specially because it has substates.
    if (ACK_LIFECYCLE_IN_SETUP_MODE == ACK_LifecycleState)
    {
        ACK_DEBUG_PRINT_I("ACK lifecycle state: SETUP MODE");
		
		printf("\n>>>>>>>>>>>>>>>>>ACK_LIFECYCLE_IN_SETUP_MODE\n");

        // Display setup type messages.
        // If you have a simple display like a blinking LED, you should present the mode by priority
        // in the order shown here.
        if (ACK_LifecycleSubStateInfo.InSetupMode.IsUserGuidedSetupActive)
        {
            ACK_DEBUG_PRINT_I("   USER GUIDED SETUP");
            anyActive = true;
        }

        if (ACK_LifecycleSubStateInfo.InSetupMode.IsBarcodeScanSetupActive)
        {
            ACK_DEBUG_PRINT_I("   BARCODE SCAN");
            anyActive = true;
        }

        if (ACK_LifecycleSubStateInfo.InSetupMode.IsZeroTouchSetupActive)
        {
            ACK_DEBUG_PRINT_I("   ZERO TOUCH SETUP");
            anyActive = true;
        }

        if (!anyActive)
        {
            ACK_DEBUG_PRINT_I("   NO SETUP MODES ACTIVE");
        }

        switch (ACK_LifecycleSubStateInfo.InSetupMode.SetupStage)
        {
        case acp_setup_stages_discoverable:
            ACK_DEBUG_PRINT_I("ACK FFS Stage: DISCOVERABLE");
            break;
        case acp_setup_stages_setup_in_progress:
            ACK_DEBUG_PRINT_I("ACK FFS Stage: SETUP IN PROGRESS");
            break;
        case acp_setup_stages_registered:
            ACK_DEBUG_PRINT_I("ACK FFS Stage: REGISTERED");
            break;
        default:
            ACK_DEBUG_PRINT_I("ACK FFS Stage: UNKNOWN");
            break;
        }

        return;
    }

    // Update user-facing elements based on the lifecycle state (other than setup, which was handled above).
    switch (ACK_LifecycleState)
    {
    case ACK_LIFECYCLE_UNAVAILABLE:
        pStateName = "UNAVAILABLE";
        break;

    case ACK_LIFECYCLE_BOOTED:
        pStateName = "BOOTED";
        break;

    case ACK_LIFECYCLE_FACTORY_RESET_IN_PROGRESS:
        pStateName = "FACTORY RESET IN PROGRESS";
        break;

    case ACK_LIFECYCLE_NOT_REGISTERED:printf("\n>>>>>>>>>>>>>>>>>ACK_LIFECYCLE_NOT_REGISTERED");
        pStateName = "MODULE NOT REGISTERED";
        break;

    case ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA:printf("\n>>>>>>>>>>>>>>>>>ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA");
        pStateName = "NOT CONNECTED TO ALEXA";
        break;

    case ACK_LIFECYCLE_CONNECTED_TO_ALEXA:printf("\n>>>>>>>>>>>>>>>>>ACK_LIFECYCLE_CONNECTED_TO_ALEXA");
        pStateName = "CONNECTED TO ALEXA";
        break;

    default:
        pStateName = "UNKNOWN";
        break;
    }

    ACK_DEBUG_PRINT_I("ACK lifecycle state: %s", pStateName);

//#endif // def ACK_DEBUG_PRINT_LEVEL
}

#endif // ndef ACK_NO_ACKUSER_ONLIFECYCLESTATECHANGE
