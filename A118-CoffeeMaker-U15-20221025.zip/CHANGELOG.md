__Version 4.1.202104181201__
- Fixed a bug where Alexa would respond “Device is unresponsive” when host micro-controller unit (HMCU) application reports an error with error message set to
  NULL.
- Added additional substates under the lifecycle state "ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA", as part of WiFi Simple Reconnect feature available in ACK
  Module Firmware 1446. Currently, this feature is supported for ACK Module with MediaTek chipset firmware 1446 only. For more information see ACK Device SDK
  v4.1.202104181201.pdf included in SDK download.

__Version 4.0.202101122015__
- Added Support for ThermostatController, TemperatureSensor, DeviceUsage.Estimation and DeviceUsage.Meter interfaces.
- Added improvements that will help in faster launch of new capability support or new features.
- Fixed compilation issues with Arduino IDE 1.8.10 or later for sample applications included in the ACK Device SDK.

__Version 3.2.202009091708__
- Added support for timeOfSample to UsageConsumedEvent and LevelUsageConsumedEvent in Dash Replenishment application. This means now you can see the time 
  stamp of ChangeReport and StateReport events.
- Fixed a bug where repeated warning statements in case of Hello World sample application was causing slow down in Alexa App control page or unresponsive 
  sometimes.
- Developers can now configure circular buffer size in ack_user_config.h file for their UART implementation. Circular buffer size was previously fixed at 32 
  bytes which can now be overridden up to 256 bytes through ack_user_config.h.
- For running validation scripts, you now need Python version 3.8 as a pre-requisite instead of python version 3.7.

__Version 3.1.202002070037__
- Extra debug-print statements added into the initialization sequence. ImplCore now debug-prints a message
  indicating when it's (re-)initializating, along with the HMCU firmware version.
- Validation scripts added, in the test\validation directory. See the readme.txt in that directory for
  more information.
- Bug fixed in STM32 over-the-air update support wherein staging partition was not being erased. Improved
  diagnostic messages (to the debug port) in OTA code.
- Hello, World sample application added to model a simple smart plug.
- Microwave sample application added.
- Reliability improved of sample applications on STM32 by increasing stack size.
- Miscellaneous compilation warnings fixed.
- Guard against overflow when allocating memory based on sizes from incoming directives.

__Version 3.0.201909161834__
- Initial public release of ACK Device SDK.